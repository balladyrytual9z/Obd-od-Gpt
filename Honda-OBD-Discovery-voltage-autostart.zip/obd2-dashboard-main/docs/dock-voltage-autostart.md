# Dock voltage bridge and boot auto-connect

## Dock voltage broadcast

The app sends fresh voltage readings from the existing `ATRV` keep-alive/polling path to the Dock app. It does not open a second Bluetooth connection and it does not rebroadcast cached snapshots.

- Action: `pl.dock.widget.OBD_VOLTAGE`
- Package target: `pl.dock.widget`
- Extra: `voltage` (`Float`, volts)
- Validation: only finite values greater than 0 V and at most 40 V are accepted.
- Rate limit: normally at most one broadcast per 2 seconds, except a change of at least 0.1 V may be sent sooner.
- The bridge is only fed from a real session, not demo mode.

Dock should mark the reading stale after 2 minutes without a new broadcast and display `-- V` as agreed in the Dock implementation.

## Automatic startup and background session

`BootReceiver` starts `ObdConnectionService` after `BOOT_COMPLETED` and `MY_PACKAGE_REPLACED`. The foreground service then attempts to connect to the adapter previously saved by the user. It uses the app's single `ObdHolder.connection`; it must not create another BLE client.

The foreground service and the connection manager's existing reconnect loop help keep the session alive while another app is in front. Android/vendor firmware can still force-stop the process or restrict startup. If the radio has a vendor-specific autostart or battery-management allowlist, allow this app there for the strongest practical persistence. A force-stop from Android Settings suppresses boot receivers until the app is manually launched again.
