package com.miskibin.obd2dashboard.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.miskibin.obd2dashboard.log.LogTag
import com.miskibin.obd2dashboard.log.ObdLog
import com.miskibin.obd2dashboard.service.ObdConnectionService

/** Starts the persistent connection service after the head unit has completed booting. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        ObdLog.log(LogTag.CONN, "startup receiver: $action; starting OBD service")
        ObdConnectionService.startAfterBoot(context.applicationContext)
    }
}
