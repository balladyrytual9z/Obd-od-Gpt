package com.miskibin.obd2dashboard

import android.content.Context
import android.content.Intent
import kotlin.math.abs

/**
 * Publishes a validated, freshly-read ECU/ELM voltage to the separate Dock application.
 * The broadcast is package-scoped so it is delivered only to pl.dock.widget.
 */
object ObdBridge {
    const val ACTION = "pl.dock.widget.OBD_VOLTAGE"
    const val EXTRA_VOLTAGE = "voltage"
    private const val DOCK_PACKAGE = "pl.dock.widget"
    private const val MIN_INTERVAL_MS = 2_000L
    private const val MIN_CHANGE_VOLTS = 0.1f

    @Volatile private var lastSentAt = 0L
    @Volatile private var lastValue = -1f

    fun publish(context: Context, volts: Float) {
        if (!volts.isFinite() || volts <= 0f || volts > 40f) return
        val now = System.currentTimeMillis()
        if (now - lastSentAt < MIN_INTERVAL_MS && abs(volts - lastValue) < MIN_CHANGE_VOLTS) return
        synchronized(this) {
            val checkedNow = System.currentTimeMillis()
            if (checkedNow - lastSentAt < MIN_INTERVAL_MS && abs(volts - lastValue) < MIN_CHANGE_VOLTS) return
            try {
                context.applicationContext.sendBroadcast(
                    Intent(ACTION)
                        .setPackage(DOCK_PACKAGE)
                        .putExtra(EXTRA_VOLTAGE, volts),
                )
                lastSentAt = checkedNow
                lastValue = volts
            } catch (_: Exception) {
                // The Dock may not be installed; diagnostics must continue normally.
            }
        }
    }
}
