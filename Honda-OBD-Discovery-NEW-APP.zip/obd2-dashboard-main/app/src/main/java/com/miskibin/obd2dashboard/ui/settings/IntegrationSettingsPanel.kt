package com.miskibin.obd2dashboard.ui.settings

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.miskibin.obd2dashboard.data.LocalApiSecret
import com.miskibin.obd2dashboard.data.ElevenLabsSecret
import com.miskibin.obd2dashboard.service.ElevenLabsSpeechService
import com.miskibin.obd2dashboard.service.AiVoiceModesService
import com.miskibin.obd2dashboard.data.LiveDataArchive
import com.miskibin.obd2dashboard.data.RefuelEntry
import com.miskibin.obd2dashboard.data.RefuelLog
import com.miskibin.obd2dashboard.ObdHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val dtcIntervals = listOf(1, 2, 5, 10, 15, 30, 60, 120, 300)

@Composable
fun IntegrationSettingsPanel(context: Context, dtcIntervalSeconds: Int, onDtcIntervalChange: (Int) -> Unit) {
    val prefs = remember(context) { context.getSharedPreferences("obd_ai_config", Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(prefs.getString("openrouter_model", "openai/gpt-4o-mini") ?: "openai/gpt-4o-mini") }
    var models by remember { mutableStateOf(emptyList<String>()) }
    var message by remember { mutableStateOf(if (LocalApiSecret.load(context) != null) "Klucz jest zapisany lokalnie w Android Keystore." else "Brak zapisanego klucza API.") }
    var loading by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("") }
    var reportWindow by remember { mutableStateOf(prefs.getLong("report_window_ms", 24L * 60 * 60 * 1000)) }
    var customHours by remember { mutableStateOf("6") }
    var litres by remember { mutableStateOf("") }
    var totalPrice by remember { mutableStateOf("") }
    var odometer by remember { mutableStateOf("") }
    var fullTank by remember { mutableStateOf(true) }
    var refuelMessage by remember { mutableStateOf("") }
    var refuels by remember { mutableStateOf(RefuelLog.all(context)) }
    var elevenApiKey by remember { mutableStateOf("") }
    var elevenVoices by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    var elevenVoiceId by remember { mutableStateOf(prefs.getString("elevenlabs_voice_id", "") ?: "") }
    var elevenMessage by remember { mutableStateOf(if (ElevenLabsSecret.load(context) != null) "Klucz ElevenLabs zapisany lokalnie." else "Brak klucza ElevenLabs.") }
    var elevenLoading by remember { mutableStateOf(false) }
    val voicePrefs = remember(context) { context.getSharedPreferences(AiVoiceModesService.STORE, Context.MODE_PRIVATE) }
    var alertsEnabled by remember { mutableStateOf(voicePrefs.getBoolean(AiVoiceModesService.KEY_ALERTS, false)) }
    var commentaryEnabled by remember { mutableStateOf(voicePrefs.getBoolean(AiVoiceModesService.KEY_COMMENTARY, false)) }
    var finishLastOnExit by remember { mutableStateOf(voicePrefs.getBoolean(AiVoiceModesService.KEY_FINISH_LAST_ON_EXIT, true)) }
    var commentaryPaused by remember { mutableStateOf(voicePrefs.getBoolean(AiVoiceModesService.KEY_COMMENTARY_PAUSED, false)) }
    var persona by remember { mutableStateOf(voicePrefs.getString(AiVoiceModesService.KEY_PERSONA, AiVoiceModesService.PERSONA_MECHANIC) ?: AiVoiceModesService.PERSONA_MECHANIC) }
    val scope = rememberCoroutineScope()
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text("Integracje OBD · automatyczne odświeżanie DTC", style = MaterialTheme.typography.titleMedium)
        Text("Domyślnie 10 s. Interwał 1 s może przeciążać wolny adapter albo wydłużać odczyt innych parametrów.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            dtcIntervals.forEach { seconds ->
                Button(onClick = { onDtcIntervalChange(seconds) }, modifier = Modifier.widthIn(min = 42.dp), enabled = seconds != dtcIntervalSeconds) {
                    Text(if (seconds >= 60) "${seconds / 60}m" else "${seconds}s")
                }
            }
        }
        Text("USTAWIENIA AI", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 18.dp))
        Text("OpenRouter · analiza i komentarze", style = MaterialTheme.typography.titleMedium)
        Text("Klucz jest szyfrowany AES-GCM; klucz szyfrujący pozostaje w Android Keystore. Model jest pobierany z katalogu OpenRouter.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("OpenRouter API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                LocalApiSecret.save(context, apiKey.trim())
                apiKey = ""
                message = if (LocalApiSecret.load(context) != null) "Klucz zapisany lokalnie." else "Klucza nie zapisano."
            }) { Text("Zapisz klucz") }
            Button(enabled = !loading, onClick = {
                loading = true
                message = "Pobieranie modeli…"
                scope.launch {
                    val token = apiKey.trim().takeIf { it.isNotEmpty() } ?: LocalApiSecret.load(context)
                    val result = withContext(Dispatchers.IO) { fetchModels(token) }
                    models = result.first
                    message = result.second
                    loading = false
                }
            }) { Text(if (loading) "Pobieranie…" else "Pobierz modele") }
        }
        OutlinedTextField(value = model, onValueChange = { model = it; prefs.edit().putString("openrouter_model", it).apply() }, label = { Text("Model ID (OpenRouter)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (models.isNotEmpty()) {
            Text("Wybierz model z listy:", style = MaterialTheme.typography.labelLarge)
            models.take(40).forEach { id ->
                Text("${if (id == model) "✓ " else ""}$id", modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)).padding(8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                // Tap via the separate button keeps the row accessible on head units.
                Button(onClick = { model = id; prefs.edit().putString("openrouter_model", id).apply() }) { Text("Ustaw ${id.take(36)}") }
            }
        }
        Text("Zakres danych do raportu", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("15 min" to 15L * 60_000, "24 h" to 24L * 60 * 60_000, "7 dni" to 7L * 24 * 60 * 60_000, "Cała historia" to 0L).forEach { (label, value) ->
                Button(onClick = { reportWindow = value; prefs.edit().putLong("report_window_ms", value).apply() }, enabled = reportWindow != value) { Text(label) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(value = customHours, onValueChange = { customHours = it }, label = { Text("Własny zakres (godz.)") }, singleLine = true, modifier = Modifier.weight(1f))
            Button(onClick = { customHours.toLongOrNull()?.takeIf { it in 1L..8760L }?.let { reportWindow = it * 60 * 60_000; prefs.edit().putLong("report_window_ms", reportWindow).apply() } }) { Text("Ustaw") }
        }
        Button(enabled = !loading, onClick = {
            loading = true
            report = ""
            message = "Przygotowywanie raportu na podstawie dostępnych danych i zapisanej historii…"
            scope.launch {
                val token = LocalApiSecret.load(context)
                val selectedModel = prefs.getString("openrouter_model", model) ?: model
                val result = withContext(Dispatchers.IO) { requestLiveReport(token, selectedModel, reportWindow, context) }
                report = result.first
                message = result.second
                loading = false
            }
        }) { Text(if (loading) "Przetwarzanie…" else "Generuj techniczny raport AI") }
        Text("ElevenLabs · głos i synteza mowy", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
        Text("Wpisz klucz ElevenLabs, pobierz głosy i wybierz jeden. Czytanie działa w osobnej usłudze pierwszoplanowej, więc przejście do launchera lub zamknięcie ekranu ustawień nie przerywa odtwarzania. Zatrzymasz je z powiadomienia.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(value = elevenApiKey, onValueChange = { elevenApiKey = it }, label = { Text("ElevenLabs API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                ElevenLabsSecret.save(context, elevenApiKey.trim())
                elevenApiKey = ""
                elevenMessage = if (ElevenLabsSecret.load(context) != null) "Klucz ElevenLabs zapisany lokalnie w Android Keystore." else "Nie udało się zapisać klucza."
            }) { Text("Zapisz klucz ElevenLabs") }
            Button(enabled = !elevenLoading, onClick = {
                elevenLoading = true
                elevenMessage = "Pobieranie dostępnych głosów…"
                scope.launch {
                    val token = elevenApiKey.trim().takeIf { it.isNotEmpty() } ?: ElevenLabsSecret.load(context)
                    val result = withContext(Dispatchers.IO) { fetchElevenLabsVoices(token) }
                    elevenVoices = result.first
                    elevenMessage = result.second
                    elevenLoading = false
                }
            }) { Text(if (elevenLoading) "Pobieranie…" else "Pobierz głosy") }
        }
        OutlinedTextField(value = elevenVoiceId, onValueChange = { elevenVoiceId = it; prefs.edit().putString("elevenlabs_voice_id", it).apply() }, label = { Text("ID głosu ElevenLabs") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (elevenVoices.isNotEmpty()) {
            Text("Wybierz głos:", style = MaterialTheme.typography.labelLarge)
            elevenVoices.take(60).forEach { (id, name) ->
                Button(onClick = { elevenVoiceId = id; prefs.edit().putString("elevenlabs_voice_id", id).apply(); elevenMessage = "Wybrano głos: $name" }, modifier = Modifier.fillMaxWidth(), enabled = id != elevenVoiceId) {
                    Text("${if (id == elevenVoiceId) "✓ " else ""}$name · ${id.take(12)}")
                }
            }
        }
        Button(enabled = report.isNotBlank() && !elevenLoading, onClick = {
            if (ElevenLabsSecret.load(context).isNullOrBlank()) elevenMessage = "Najpierw zapisz klucz ElevenLabs."
            else if (elevenVoiceId.isBlank()) elevenMessage = "Pobierz głosy i wybierz głos lub wpisz jego ID."
            else {
                val intent = android.content.Intent(context, ElevenLabsSpeechService::class.java)
                    .putExtra(ElevenLabsSpeechService.EXTRA_TEXT, report)
                    .putExtra(ElevenLabsSpeechService.EXTRA_VOICE_ID, elevenVoiceId)
                androidx.core.content.ContextCompat.startForegroundService(context, intent)
                elevenMessage = "Uruchomiono czytanie w tle. Możesz wyjść z aplikacji; powiadomienie pozwala zatrzymać odtwarzanie."
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Czytaj wygenerowany raport") }

        Text("TRYBY GŁOSOWE PODCZAS JAZDY", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 18.dp))
        Text("Oba tryby wymagają zapisanego klucza ElevenLabs i wybranego głosu. Komentowanie wymaga dodatkowo klucza OpenRouter i używa bieżących, faktycznie odczytanych danych OBD. Nie komentuje parametrów, których adapter nie udostępnia.", style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Alarmy głosowe", style = MaterialTheme.typography.titleMedium)
                Text("Mówi tylko o nowych kodach DTC i wykrytych alertach temperatury.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = alertsEnabled, onCheckedChange = { enabled ->
                if (enabled && (ElevenLabsSecret.load(context).isNullOrBlank() || elevenVoiceId.isBlank())) {
                    elevenMessage = "Aby włączyć alarmy, zapisz klucz ElevenLabs i wybierz głos."
                } else {
                    alertsEnabled = enabled; voicePrefs.edit().putBoolean(AiVoiceModesService.KEY_ALERTS, enabled).apply()
                    val action = if (enabled || commentaryEnabled) null else AiVoiceModesService.ACTION_STOP
                    val intent = android.content.Intent(context, AiVoiceModesService::class.java).apply { action?.let { setAction(it) } }
                    if (action == null) androidx.core.content.ContextCompat.startForegroundService(context, intent)
                    else runCatching { context.startService(intent) }
                }
            })
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Komentowanie sytuacji", style = MaterialTheme.typography.titleMedium)
                Text("Co najwyżej jeden krótki komentarz co 90 sekund, gdy auto jedzie; wybierz rolę.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = commentaryEnabled, onCheckedChange = { enabled ->
                if (enabled && (ElevenLabsSecret.load(context).isNullOrBlank() || elevenVoiceId.isBlank())) {
                    elevenMessage = "Aby włączyć komentowanie, zapisz klucz ElevenLabs i wybierz głos."
                } else if (enabled && LocalApiSecret.load(context).isNullOrBlank()) {
                    elevenMessage = "Komentowanie AI wymaga najpierw zapisania klucza OpenRouter."
                } else {
                    commentaryEnabled = enabled; voicePrefs.edit().putBoolean(AiVoiceModesService.KEY_COMMENTARY, enabled).apply()
                    val intent = android.content.Intent(context, AiVoiceModesService::class.java)
                    if (enabled || alertsEnabled) androidx.core.content.ContextCompat.startForegroundService(context, intent)
                    else { intent.action = AiVoiceModesService.ACTION_STOP; runCatching { context.startService(intent) } }
                }
            })
        }
        Text("Rola komentarza", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            listOf(AiVoiceModesService.PERSONA_MECHANIC to "Mechanik", AiVoiceModesService.PERSONA_FIRE to "Strażak", AiVoiceModesService.PERSONA_ECO to "Eco-driving").forEach { (id, label) ->
                Button(onClick = { persona = id; voicePrefs.edit().putString(AiVoiceModesService.KEY_PERSONA, id).apply() }, enabled = persona != id) { Text(if (persona == id) "✓ $label" else label) }
            }
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Po wyjściu z aplikacji dokończ tylko bieżący komentarz", style = MaterialTheme.typography.bodyMedium)
                Text("Nie rozpoczynaj nowych komentarzy w tle. Alarmy głosowe pozostają aktywne.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = finishLastOnExit, onCheckedChange = { value -> finishLastOnExit = value; voicePrefs.edit().putBoolean(AiVoiceModesService.KEY_FINISH_LAST_ON_EXIT, value).apply() })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(enabled = commentaryEnabled, onClick = {
                commentaryPaused = !commentaryPaused
                voicePrefs.edit().putBoolean(AiVoiceModesService.KEY_COMMENTARY_PAUSED, commentaryPaused).apply()
                val intent = android.content.Intent(context, AiVoiceModesService::class.java).setAction(if (commentaryPaused) AiVoiceModesService.ACTION_PAUSE_COMMENTARY else AiVoiceModesService.ACTION_RESUME_COMMENTARY)
                androidx.core.content.ContextCompat.startForegroundService(context, intent)
            }) { Text(if (commentaryPaused) "Wznów komentarze" else "Wstrzymaj komentarze") }
            Button(onClick = {
                val intent = android.content.Intent(context, AiVoiceModesService::class.java).setAction(AiVoiceModesService.ACTION_STOP)
                runCatching { context.startService(intent) }
                alertsEnabled = false; commentaryEnabled = false
                voicePrefs.edit().putBoolean(AiVoiceModesService.KEY_ALERTS, false).putBoolean(AiVoiceModesService.KEY_COMMENTARY, false).apply()
            }) { Text("Wyłącz tryby") }
        }
        Text(elevenMessage, style = MaterialTheme.typography.bodySmall)
        Text("DANE DIAGNOSTYCZNE I INTEGRACJE", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 18.dp))
        Text("Historia LIVE jest zapisywana lokalnie w JSONL bez automatycznego limitu retencji. Pierwsze uruchomienie nie zawiera danych sprzed instalacji tej wersji.", style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            val file = LiveDataArchive.makeExportCopy(context)
            if (file == null) {
                message = "Brak zapisanej historii LIVE do eksportu."
            } else {
                val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.files", file)
                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).setType("application/x-ndjson")
                    .putExtra(android.content.Intent.EXTRA_SUBJECT, "Honda OBD - archiwum LIVE JSONL")
                    .putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.clipData = android.content.ClipData.newRawUri(file.name, uri)
                context.startActivity(android.content.Intent.createChooser(intent, "Eksport historii OBD"))
            }
        }) { Text("Eksport całej historii LIVE (JSONL)") }
        Text("Tankowania i zużycie paliwa", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
        Text("Wpisz dane z paragonu i licznika. Zużycie L/100 km jest liczone metodą pełny bak–pełny bak; bez dwóch tankowań pełnych wynik nie jest wyliczany.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(value = litres, onValueChange = { litres = it }, label = { Text("Litry") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = totalPrice, onValueChange = { totalPrice = it }, label = { Text("Łączny koszt (zł)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = odometer, onValueChange = { odometer = it }, label = { Text("Przebieg (km)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        androidx.compose.material3.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(checked = fullTank, onCheckedChange = { fullTank = it })
            Text("Zatankowano do pełna")
        }
        Button(onClick = {
            val l = litres.replace(',', '.').toDoubleOrNull()
            val cost = totalPrice.replace(',', '.').toDoubleOrNull()
            val km = odometer.replace(',', '.').toDoubleOrNull()
            if (l == null || l <= 0 || cost == null || cost < 0 || km == null || km < 0) {
                refuelMessage = "Wpisz poprawne litry, koszt i przebieg."
            } else {
                RefuelLog.add(context, RefuelEntry(timestampMillis = System.currentTimeMillis(), odometerKm = km, litres = l, totalCost = cost, fullTank = fullTank))
                refuels = RefuelLog.all(context)
                litres = ""; totalPrice = ""; odometer = ""
                val consumption = RefuelLog.latestFullToFull(context)
                refuelMessage = consumption?.let { "Ostatni wynik pełny–pełny: %.2f L/100 km na %.0f km".format(java.util.Locale.ROOT, it.second, it.first) } ?: "Tankowanie zapisane. Do wyliczenia zużycia potrzeba dwóch tankowań oznaczonych jako pełny bak."
            }
        }) { Text("Zapisz tankowanie") }
        Text("Zapisane tankowania: ${refuels.size}", style = MaterialTheme.typography.bodySmall)
        if (refuels.isNotEmpty()) {
            val litresTotal = refuels.sumOf { it.litres }
            val costTotal = refuels.sumOf { it.totalCost }
            Text("Łącznie: %.1f l • %.2f zł • średnio %.2f zł/l".format(java.util.Locale.ROOT, litresTotal, costTotal, if (litresTotal > 0) costTotal / litresTotal else 0.0), style = MaterialTheme.typography.bodyMedium)
            RefuelLog.latestFullToFull(context)?.let { result ->
                Text("Zużycie z ostatniego pełny–pełny: %.2f l/100 km (%.0f km)".format(java.util.Locale.ROOT, result.second, result.first), style = MaterialTheme.typography.bodyMedium)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = refuels.isNotEmpty(), onClick = {
                val csv = buildString {
                    appendLine("timestamp_iso,odometer_km,litres,total_cost_pln,full_tank,note")
                    refuels.sortedBy(RefuelEntry::timestampMillis).forEach { e ->
                        appendLine("${java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", java.util.Locale.ROOT).format(java.util.Date(e.timestampMillis))},${e.odometerKm},${e.litres},${e.totalCost},${e.fullTank},\"${e.note.replace("\"", "\"\"")}\"")
                    }
                }
                val share = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/csv")
                    .putExtra(android.content.Intent.EXTRA_SUBJECT, "Honda OBD - tankowania")
                    .putExtra(android.content.Intent.EXTRA_TEXT, csv)
                context.startActivity(android.content.Intent.createChooser(share, "Eksport tankowań"))
            }) { Text("Eksport CSV") }
        }
        refuels.sortedByDescending { it.timestampMillis }.take(5).forEach { e ->
            Text("${java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ROOT).format(java.util.Date(e.timestampMillis))} • %.1f l • %.2f zł • %.0f km%s".format(java.util.Locale.ROOT, e.litres, e.totalCost, e.odometerKm, if (e.fullTank) " • pełny" else ""), style = MaterialTheme.typography.bodySmall)
        }
        if (refuelMessage.isNotBlank()) Text(refuelMessage, style = MaterialTheme.typography.bodySmall)
        if (report.isNotBlank()) Text(report, style = MaterialTheme.typography.bodySmall, modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)).padding(12.dp))
        val lastClear = remember { context.getSharedPreferences("obd_dtc_clear", Context.MODE_PRIVATE).getString("last_result", null) }
        if (lastClear != null) Text("Ostatni wynik Kasuj DTC: $lastClear", style = MaterialTheme.typography.bodySmall)
        Text(message, style = MaterialTheme.typography.bodySmall)
    }
}

private fun fetchModels(token: String?): Pair<List<String>, String> {
    if (token.isNullOrBlank()) return emptyList<String>() to "Najpierw wpisz i zapisz klucz API."
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL("https://openrouter.ai/api/v1/models").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/json")
        }
        if (connection.responseCode !in 200..299) return emptyList<String>() to "OpenRouter zwrócił HTTP ${connection.responseCode}. Sprawdź klucz i sieć."
        val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        val data = root.optJSONArray("data") ?: return emptyList<String>() to "Odpowiedź nie zawiera listy modeli."
        val result = (0 until data.length()).mapNotNull { data.optJSONObject(it)?.optString("id")?.takeIf(String::isNotBlank) }.sorted()
        result to "Pobrano ${result.size} modeli. Dotknij przycisku przy modelu, aby go wybrać."
    } catch (e: Exception) {
        emptyList<String>() to "Nie udało się pobrać modeli: ${e.javaClass.simpleName}: ${e.message ?: "błąd sieci"}"
    } finally { connection?.disconnect() }
}


private fun fetchElevenLabsVoices(token: String?): Pair<List<Pair<String, String>>, String> {
    if (token.isNullOrBlank()) return emptyList<Pair<String, String>>() to "Najpierw wpisz i zapisz klucz ElevenLabs."
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL("https://api.elevenlabs.io/v1/voices").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("xi-api-key", token)
            setRequestProperty("Accept", "application/json")
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val root = JSONObject(stream.bufferedReader().use { it.readText() })
        if (code !in 200..299) return emptyList<Pair<String, String>>() to "ElevenLabs HTTP $code: ${root.optString("detail", root.toString()).take(240)}"
        val array = root.optJSONArray("voices") ?: return emptyList<Pair<String, String>>() to "Odpowiedź ElevenLabs nie zawiera listy głosów."
        val voices = (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            val id = item.optString("voice_id")
            val name = item.optString("name", id)
            if (id.isBlank()) null else id to name
        }.sortedBy { it.second.lowercase() }
        voices to "Pobrano ${voices.size} głosów ElevenLabs. Wybierz głos z listy."
    } catch (e: Exception) {
        emptyList<Pair<String, String>>() to "Nie udało się pobrać głosów: ${e.javaClass.simpleName}: ${e.message ?: "błąd sieci"}"
    } finally { connection?.disconnect() }
}

private fun requestLiveReport(token: String?, model: String, windowMillis: Long, context: Context): Pair<String, String> {
    if (token.isNullOrBlank()) return "" to "Zapisz klucz OpenRouter przed generowaniem raportu."
    if (model.isBlank()) return "" to "Wybierz lub wpisz ID modelu."
    var connection: HttpURLConnection? = null
    return try {
        val snapshot = ObdHolder.connection.snapshot.value
        val diagnostics = ObdHolder.connection.diagnostics.value
        val live = JSONObject().put("vehicle", "Honda Civic VIII UFO 2010, L13Z1 1.4 i-VTEC 100 KM, manual, FWD")
            .put("timestampMillis", snapshot.updatedAtMillis)
            .put("batteryVoltageECUOrAdapter", snapshot.batteryVoltage ?: JSONObject.NULL)
            .put("batteryTimestampMillis", snapshot.batteryAtMillis)
        val values = org.json.JSONArray()
        snapshot.readings.values.forEach { r -> values.put(JSONObject().put("pid", r.key).put("name", r.name).put("value", r.value).put("unit", r.unit).put("timestampMillis", r.timestampMillis).put("quality", if (System.currentTimeMillis() - r.timestampMillis > 5000) "STALE" else "LIVE")) }
        snapshot.extended.values.forEach { r -> values.put(JSONObject().put("id", r.id).put("value", r.value).put("unit", r.unit).put("timestampMillis", r.timestampMillis).put("quality", if (System.currentTimeMillis() - r.timestampMillis > 5000) "STALE" else "LIVE")) }
        live.put("readings", values).put("dtc", org.json.JSONArray(diagnostics.value?.all.orEmpty().map { "${it.kind.name}:${it.code}" }))
        val since = if (windowMillis <= 0L) 0L else System.currentTimeMillis() - windowMillis
        val archived = LiveDataArchive.readSince(context.applicationContext, since)
        val history = org.json.JSONArray()
        archived.forEach { history.put(it) }
        live.put("historyWindowMillis", windowMillis).put("historySamples", history)
        val body = JSONObject().put("model", model).put("temperature", 0.2).put("messages", org.json.JSONArray()
            .put(JSONObject().put("role", "system").put("content", "Jesteś technicznym asystentem diagnostyki OBD. Odpowiadaj po polsku. Odróżniaj fakty, hipotezy i braki danych. Nie zalecaj wymiany części bez testów. Nie twierdź, że wartość LIVE, jeśli jej znacznik czasu jest stary. Struktura: podsumowanie i pilność; obserwacje; możliwe przyczyny z pewnością; kolejne testy; ograniczenia danych."))
            .put(JSONObject().put("role", "user").put("content", "Przeanalizuj aktualne dane OBD oraz próbki archiwalne z wybranego zakresu. Raport techniczny, ale zrozumiały. Jawnie podaj zakres czasu, liczbę próbek i ograniczenia historii.\n" + live.toString(2))))
        connection = (URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
            setRequestProperty("Authorization", "Bearer $token"); setRequestProperty("Content-Type", "application/json")
            setRequestProperty("HTTP-Referer", "https://github.com/miskibin/obd2-dashboard"); setRequestProperty("X-Title", "Honda OBD Discovery")
        }
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = JSONObject(stream.bufferedReader().use { it.readText() })
        if (code !in 200..299) return "" to "OpenRouter HTTP $code: ${response.optString("error", response.toString()).take(400)}"
        val content = response.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
        if (content.isNullOrBlank()) "" to "Model nie zwrócił treści raportu." else content to "Raport wygenerowany z aktualnego snapshotu i zapisanych próbek w wybranym zakresie. Historia nie obejmuje danych sprzed włączenia archiwizacji; nie wszystkie PID-y muszą być obsługiwane przez ECU."
    } catch (e: Exception) {
        "" to "Błąd raportowania AI: ${e.javaClass.simpleName}: ${e.message ?: "brak szczegółów"}"
    } finally { connection?.disconnect() }
}
