package com.miskibin.obd2dashboard.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.Lifecycle
import com.miskibin.obd2dashboard.MainActivity
import com.miskibin.obd2dashboard.R
import com.miskibin.obd2dashboard.data.ElevenLabsSecret
import com.miskibin.obd2dashboard.data.LocalApiSecret
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Voice modes driven only by values actually emitted by the OBD layer. */
class AiVoiceModesService : Service() {
    private var rootJob = SupervisorJob()
    private var scope = CoroutineScope(Dispatchers.Main + rootJob)
    private var player: MediaPlayer? = null
    private var currentAudio: File? = null
    private var speakingJob: Job? = null
    private var lastCommentAt = 0L
    private var lastAlertAt = 0L
    private var lastDtcSignature = ""
    private var lastAlertKey = ""
    private var lastPayload: JSONObject? = null
    private var receiverRegistered = false

    private val liveReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val raw = intent?.getStringExtra("payloadJson") ?: return
            val payload = runCatching { JSONObject(raw) }.getOrNull() ?: return
            lastPayload = payload
            if (!modes().getBoolean(KEY_ALERTS, false) && !modes().getBoolean(KEY_COMMENTARY, false)) return
            evaluateAlerts(payload)
            if (modes().getBoolean(KEY_COMMENTARY, false)) maybeComment(payload)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val filter = IntentFilter("com.miskibin.obd2dashboard.LIVE_DATA")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(liveReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(liveReceiver, filter)
        }
        receiverRegistered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            ACTION_PAUSE_COMMENTARY -> { modes().edit().putBoolean(KEY_COMMENTARY_PAUSED, true).apply(); updateNotification("Komentowanie wstrzymane; alarmy nadal działają") }
            ACTION_RESUME_COMMENTARY -> { modes().edit().putBoolean(KEY_COMMENTARY_PAUSED, false).apply(); updateNotification("Komentowanie wznowione") }
        }
        startForeground(NOTIFICATION_ID, notification("Aktywne tryby głosowe OBD"))
        val prefs = modes()
        if (ElevenLabsSecret.load(this).isNullOrBlank() || selectedVoice().isBlank()) {
            updateNotification("Brak klucza ElevenLabs lub wybranego głosu")
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (!prefs.getBoolean(KEY_ALERTS, false) && !prefs.getBoolean(KEY_COMMENTARY, false)) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun modes() = getSharedPreferences(STORE, Context.MODE_PRIVATE)

    private fun evaluateAlerts(payload: JSONObject) {
        if (!modes().getBoolean(KEY_ALERTS, false)) return
        val readings = payload.optJSONArray("readings") ?: JSONArray()
        var coolant: Double? = null
        readings.forEachObject { item ->
            val name = item.optString("name").lowercase()
            val key = item.optString("key").lowercase()
            val value = item.optDouble("value", Double.NaN)
            val fresh = item.optString("quality") == "LIVE" && System.currentTimeMillis() - item.optLong("timestampMillis", 0L) <= 5000L
            if ((name.contains("coolant") || name.contains("engine coolant") || key.contains("coolant")) && value.isFinite() && fresh) coolant = value
        }
        val dtcs = payload.optJSONArray("dtcs") ?: JSONArray()
        val codes = mutableListOf<String>()
        dtcs.forEachObject { item -> item.optString("code").takeIf { it.isNotBlank() }?.let(codes::add) }
        val signature = codes.sorted().joinToString(",")
        val now = System.currentTimeMillis()
        var alert: String? = null
        var key = ""
        if (coolant != null && coolant!! >= 115.0) {
            key = "coolant-critical"
            alert = "STOP. Temperatura płynu chłodzącego wynosi ${coolant!!.toInt()} stopni. Bezpiecznie zatrzymaj samochód. Nie otwieraj korka chłodnicy na gorącym silniku."
        } else if (coolant != null && coolant!! >= 110.0) {
            key = "coolant-high"
            alert = "Uwaga. Temperatura płynu chłodzącego wynosi ${coolant!!.toInt()} stopni. Obserwuj temperaturę i zatrzymaj się bezpiecznie, jeśli nadal rośnie."
        }
        if (signature.isNotBlank() && signature != lastDtcSignature && alert == null) {
            key = "dtc:$signature"
            alert = "Wykryto kody usterek: ${codes.joinToString(", ")}. Sprawdź diagnostykę OBD przed dalszą jazdą."
        }
        lastDtcSignature = signature
        if (alert != null && (key != lastAlertKey || now - lastAlertAt > 120_000L)) {
            lastAlertKey = key; lastAlertAt = now
            speak(alert, priority = true)
        }
    }

    private fun maybeComment(payload: JSONObject) {
        val prefs = modes()
        if (prefs.getBoolean(KEY_COMMENTARY_PAUSED, false)) return
        val finishOnly = prefs.getBoolean(KEY_FINISH_LAST_ON_EXIT, true)
        val appForeground = runCatching { ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED) }.getOrDefault(true)
        if (finishOnly && !appForeground) return // let the current audio finish; do not start another thread
        val now = System.currentTimeMillis()
        if (now - lastCommentAt < 90_000L || speakingJob?.isActive == true) return
        val speed = findValue(payload, "vehicle_speed", "vehicle speed")
        if (speed == null || speed < 5.0) return
        val openRouter = LocalApiSecret.load(this) ?: return
        val eleven = ElevenLabsSecret.load(this) ?: return
        val voice = selectedVoice()
        val model = getSharedPreferences("obd_ai_config", Context.MODE_PRIVATE).getString("openrouter_model", "openai/gpt-4o-mini") ?: "openai/gpt-4o-mini"
        val role = prefs.getString(KEY_PERSONA, PERSONA_MECHANIC) ?: PERSONA_MECHANIC
        lastCommentAt = now
        speakingJob = scope.launch {
            try {
                updateNotification("Analizuję bieżące dane: ${personaLabel(role)}")
                val comment = withContext(Dispatchers.IO) { generateComment(openRouter, model, role, payload) }
                if (comment.isNotBlank()) speak(comment.take(900), priority = false, token = eleven, voiceId = voice)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { updateNotification("Komentarz niedostępny: ${(e.message ?: "błąd AI").take(80)}") }
        }
    }

    private fun findValue(payload: JSONObject, vararg query: String): Double? {
        val readings = payload.optJSONArray("readings") ?: return null
        for (i in 0 until readings.length()) {
            val r = readings.optJSONObject(i) ?: continue
            val haystack = (r.optString("key") + " " + r.optString("name")).lowercase()
            if (query.any { haystack.contains(it) }) {
                val value = r.optDouble("value", Double.NaN)
                if (value.isFinite()) return value
            }
        }
        return null
    }

    private suspend fun generateComment(token: String, model: String, persona: String, payload: JSONObject): String {
        val readings = payload.optJSONArray("readings") ?: JSONArray()
        val compact = JSONArray()
        readings.forEachObject { r ->
            val q = r.optString("quality")
            if (q == "LIVE") compact.put(JSONObject().put("name", r.optString("name")).put("value", r.opt("value")).put("unit", r.optString("unit")))
        }
        val dtcs = payload.optJSONArray("dtcs") ?: JSONArray()
        val rolePrompt = when (persona) {
            PERSONA_FIRE -> "Jesteś krótkim, ostrożnym asystentem bezpieczeństwa. Wskazuj tylko realne sygnały ryzyka widoczne w danych. Nie diagnozuj ciśnienia oleju ani hamulców, jeśli nie ma takich pomiarów. Jeśli nie ma nic ważnego, powiedz jedno praktyczne zdanie o monitorowaniu."
            PERSONA_ECO -> "Jesteś instruktorem eco-drivingu. Dawaj jedną krótką, możliwą do zastosowania wskazówkę opartą wyłącznie na dostępnych pomiarach. Nie twierdź, że znasz ciśnienie opon, spalanie chwilowe ani oszczędność procentową, jeśli dane tego nie potwierdzają."
            else -> "Jesteś rzeczowym mechanikiem diagnostykiem OBD. Podaj najważniejszą obserwację i następny sensowny krok. Odróżniaj pomiar od hipotezy; nie przypisuj przyczyny bez dowodów."
        }
        val user = JSONObject().put("vehicle", payload.optJSONObject("vehicle") ?: JSONObject())
            .put("connection", payload.optString("connection"))
            .put("batteryVoltage", payload.opt("batteryVoltage"))
            .put("liveReadings", compact).put("dtcs", dtcs)
            .put("readiness", payload.optJSONObject("readiness") ?: JSONObject())
        val body = JSONObject().put("model", model).put("temperature", 0.2).put("max_tokens", 130)
            .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "$rolePrompt Odpowiadaj po polsku, maksymalnie 2 krótkie zdania, bez wstępów. Jeśli dane są niepełne lub stare, powiedz to. Nie wymyślaj danych ani usterek."))
                .put(JSONObject().put("role", "user").put("content", "Aktualny zrzut OBD: $user")))
        val conn = (URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection)
        try {
            conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 30000; conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $token"); conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val raw = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("OpenRouter HTTP $code")
            return JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty().trim()
        } finally { conn.disconnect() }
    }

    private fun speak(text: String, priority: Boolean, token: String? = null, voiceId: String? = null) {
        if (text.isBlank()) return
        if (priority) {
            speakingJob?.cancel(); stopPlayer()
        } else if (player != null) return
        val api = token ?: ElevenLabsSecret.load(this) ?: return
        val voice = voiceId ?: selectedVoice()
        if (voice.isBlank()) return
        speakingJob = scope.launch {
            try {
                updateNotification(if (priority) "Alarm głosowy" else "Czytam komentarz")
                val file = withContext(Dispatchers.IO) { synthesize(api, voice, text) }
                currentAudio = file
                playAndAwait(file)
                file.delete(); currentAudio = null
                updateNotification("Tryby głosowe aktywne")
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { updateNotification("Błąd syntezy: ${(e.message ?: "audio").take(70)}") }
        }
    }

    private fun synthesize(token: String, voiceId: String, text: String): File {
        val conn = URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 60000; conn.doOutput = true
            conn.setRequestProperty("xi-api-key", token); conn.setRequestProperty("Content-Type", "application/json"); conn.setRequestProperty("Accept", "audio/mpeg")
            val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2")
                .put("voice_settings", JSONObject().put("stability", 0.55).put("similarity_boost", 0.75))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("ElevenLabs HTTP $code")
            val file = File(cacheDir, "voice_mode_${System.currentTimeMillis()}.mp3")
            conn.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            return file
        } finally { conn.disconnect() }
    }

    private suspend fun playAndAwait(file: File) = suspendCancellableCoroutine<Unit> { cont ->
        val mp = MediaPlayer(); player = mp
        mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        mp.setOnCompletionListener { stopPlayer(); if (cont.isActive) cont.resume(Unit) }
        mp.setOnErrorListener { _, what, extra -> stopPlayer(); if (cont.isActive) cont.resumeWithException(IllegalStateException("Audio $what/$extra")); true }
        cont.invokeOnCancellation { stopPlayer() }
        try { mp.setDataSource(file.absolutePath); mp.setOnPreparedListener { it.start() }; mp.prepareAsync() }
        catch (e: Exception) { stopPlayer(); if (cont.isActive) cont.resumeWithException(e) }
    }

    private fun stopPlayer() { runCatching { player?.stop() }; runCatching { player?.release() }; player = null; currentAudio?.delete(); currentAudio = null }
    private fun selectedVoice(): String = modes().getString(KEY_VOICE, null)
        ?.takeIf { it.isNotBlank() }
        ?: getSharedPreferences("obd_ai_config", Context.MODE_PRIVATE).getString(KEY_VOICE, "").orEmpty()

    private fun personaLabel(value: String) = when (value) { PERSONA_FIRE -> "Strażak"; PERSONA_ECO -> "Eco-driving"; else -> "Mechanik" }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Głosowe tryby Honda OBD", NotificationManager.IMPORTANCE_LOW).apply { setSound(null, null) })
    }
    private fun notification(status: String): Notification {
        val open = PendingIntent.getActivity(this, 21, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val pauseAction = if (modes().getBoolean(KEY_COMMENTARY_PAUSED, false)) ACTION_RESUME_COMMENTARY else ACTION_PAUSE_COMMENTARY
        val pauseLabel = if (pauseAction == ACTION_RESUME_COMMENTARY) "Wznów komentarze" else "Wstrzymaj komentarze"
        val pause = PendingIntent.getService(this, 22, Intent(this, AiVoiceModesService::class.java).setAction(pauseAction), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 23, Intent(this, AiVoiceModesService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_launcher_foreground).setContentTitle("Honda OBD • tryby głosowe")
            .setContentText(status).setContentIntent(open).setOnlyAlertOnce(true).setOngoing(true)
            .addAction(0, pauseLabel, pause).addAction(0, "Wyłącz", stop).build()
    }
    private fun updateNotification(text: String) { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text)) }

    override fun onDestroy() {
        if (receiverRegistered) runCatching { unregisterReceiver(liveReceiver) }
        speakingJob?.cancel(); stopPlayer(); scope.cancel(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    private inline fun JSONArray.forEachObject(block: (JSONObject) -> Unit) { for (i in 0 until length()) optJSONObject(i)?.let(block) }

    companion object {
        const val STORE = "obd_voice_modes"
        const val KEY_ALERTS = "voice_alerts_enabled"
        const val KEY_COMMENTARY = "voice_commentary_enabled"
        const val KEY_COMMENTARY_PAUSED = "voice_commentary_paused"
        const val KEY_FINISH_LAST_ON_EXIT = "voice_finish_last_on_exit"
        const val KEY_PERSONA = "voice_commentary_persona"
        const val KEY_VOICE = "elevenlabs_voice_id"
        const val PERSONA_MECHANIC = "mechanic"
        const val PERSONA_FIRE = "firefighter"
        const val PERSONA_ECO = "eco"
        const val ACTION_STOP = "com.miskibin.obd2dashboard.voice.STOP"
        const val ACTION_PAUSE_COMMENTARY = "com.miskibin.obd2dashboard.voice.PAUSE_COMMENTARY"
        const val ACTION_RESUME_COMMENTARY = "com.miskibin.obd2dashboard.voice.RESUME_COMMENTARY"
        private const val CHANNEL_ID = "honda_obd_voice_modes"
        private const val NOTIFICATION_ID = 7130
    }
}
