package com.miskibin.obd2dashboard

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.widget.RemoteViews
import com.miskibin.obd2dashboard.ble.ConnectionState
import com.miskibin.obd2dashboard.data.worstMisfire
import com.miskibin.obd2dashboard.data.Metrics
import com.miskibin.obd2dashboard.data.valueOf
import com.miskibin.obd2dashboard.obd.VehicleSnapshot
import java.util.Locale

/** Real Android home-screen widget backed by the same in-process OBD connection. */
class MisfireWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, MisfireWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_misfire_monitor)
            val state = runCatching { ObdHolder.connection.state.value }.getOrNull()
            val snapshot: VehicleSnapshot? = runCatching { ObdHolder.connection.snapshot.value }.getOrNull()
            val connected = state is ConnectionState.Connected && !state.demo
            val rpm = if (connected) snapshot?.valueOf(Metrics.Rpm) else null
            val ect = if (connected) snapshot?.valueOf(Metrics.CoolantTemp) else null
            val misfire = if (connected) runCatching { ObdHolder.connection.monitors.value.worstMisfire() }.getOrNull() else null
            views.setTextViewText(R.id.widget_connection, if (connected) "POŁĄCZONO" else "BRAK POŁĄCZENIA")
            views.setTextViewText(R.id.widget_rpm, rpm?.let { String.format(Locale.getDefault(), "%.0f", it) } ?: "—")
            views.setTextViewText(R.id.widget_ect, ect?.let { String.format(Locale.getDefault(), "%.0f °C", it) } ?: "— °C")
            views.setTextViewText(R.id.widget_misfire, misfire?.let { String.format(Locale.getDefault(), "%.0f", it.count) } ?: "BRAK DANYCH")
            val samples = if (connected) runCatching { ObdHolder.history.series(Metrics.Rpm, 30_000L) }.getOrDefault(emptyList()) else emptyList()
            val chart = drawRpmTrace(samples.map { it.value.toDouble() }) ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            views.setImageViewBitmap(R.id.widget_rpm_chart, chart)
            val open = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pending = android.app.PendingIntent.getActivity(context, 712, open,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or (if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0))
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(id, views)
        }

        /** Draws only actual recent RPM samples; empty history stays blank, never simulated. */
        private fun drawRpmTrace(values: List<Double>): Bitmap? {
            if (values.size < 2) return null
            val width = 640
            val height = 72
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(155, 231, 196)
                strokeWidth = 3.5f
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }
            val min = values.minOrNull() ?: return null
            val max = values.maxOrNull() ?: return null
            val span = (max - min).coerceAtLeast(250.0)
            val path = Path()
            values.forEachIndexed { index, value ->
                val x = index.toFloat() / (values.size - 1).toFloat() * (width - 8) + 4
                val y = height - 5 - (((value - min) / span) * (height - 12)).toFloat()
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
            return bitmap
        }
    }
}
