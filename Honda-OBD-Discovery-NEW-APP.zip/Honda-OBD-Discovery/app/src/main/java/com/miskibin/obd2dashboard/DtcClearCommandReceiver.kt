package com.miskibin.obd2dashboard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.miskibin.obd2dashboard.ble.ConnectionState
import com.miskibin.obd2dashboard.service.ObdConnectionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean

/** Receives a signed request from the standalone Kasuj DTC APK and uses the one shared OBD owner. */
class DtcClearCommandReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != ACTION_CLEAR) return
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                if (!busy.compareAndSet(false, true)) {
                    notifyResult(app, "Operacja kasowania DTC już trwa")
                    return@launch
                }
                var result = "Niepowodzenie: brak połączenia z ECU"
                try {
                    var state = ObdHolder.connection.state.value
                    if (state !is ConnectionState.Connected) {
                        if (state == ConnectionState.Idle || state is ConnectionState.Error) {
                            val started = ObdHolder.autoConnect(app)
                            if (started) {
                                ObdConnectionService.start(app)
                                state = withTimeoutOrNull(CONNECT_TIMEOUT_MS) {
                                    ObdHolder.connection.state.first {
                                        it is ConnectionState.Connected || it is ConnectionState.Error
                                    }
                                } ?: state
                            } else {
                                result = "Brak zapamiętanego adaptera BLE lub brak uprawnień"
                            }
                        } else {
                            state = withTimeoutOrNull(CONNECT_TIMEOUT_MS) {
                                ObdHolder.connection.state.first {
                                    it is ConnectionState.Connected || it is ConnectionState.Error
                                }
                            } ?: state
                        }
                    }
                    if (state is ConnectionState.Connected && !state.demo) {
                        val accepted = withContext(Dispatchers.IO) { ObdHolder.connection.clearDtcs() }
                        val diagnostics = ObdHolder.connection.diagnostics.value
                        result = when {
                            !accepted -> "Niepowodzenie: ECU nie potwierdziło kasowania"
                            diagnostics == null -> "Brak możliwości zweryfikowania wyniku kasowania"
                            diagnostics.all.isEmpty() -> "Kasowanie DTC potwierdzone; brak widocznych kodów"
                            else -> "Komenda przyjęta, ale nadal odczytano ${diagnostics.all.size} kodów DTC"
                        }
                    } else if (state is ConnectionState.Error) {
                        result = "Niepowodzenie połączenia: ${state.reason}"
                    } else if (state !is ConnectionState.Connected) {
                        result = "Niepowodzenie: nie udało się połączyć z ECU"
                    } else {
                        result = "Kasowanie niedostępne w trybie demonstracyjnym"
                    }
                } catch (t: Throwable) {
                    result = "Błąd: ${t.message ?: t.javaClass.simpleName}"
                } finally {
                    busy.set(false)
                }
                notifyResult(app, result)
            } finally {
                pending.finish()
            }
        }
    }

    private fun notifyResult(context: Context, message: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "Kasowanie DTC", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Honda OBD · Kasuj DTC")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .build()
        runCatching { manager.notify(NOTIFICATION_ID, notification) }
    }

    companion object {
        const val ACTION_CLEAR = "com.miskibin.obd2dashboard.action.CLEAR_DTC"
        private const val CHANNEL = "dtc_clear_result"
        private const val NOTIFICATION_ID = 4204
        private const val CONNECT_TIMEOUT_MS = 20_000L
        private val busy = AtomicBoolean(false)
    }
}
