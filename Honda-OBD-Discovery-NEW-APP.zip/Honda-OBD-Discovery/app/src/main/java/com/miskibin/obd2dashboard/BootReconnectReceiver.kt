package com.miskibin.obd2dashboard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.miskibin.obd2dashboard.service.ObdConnectionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Boot-time silent reconnect. It never launches an activity over DiPlay/CarPlay. */
class BootReconnectReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED && intent?.action != Intent.ACTION_LOCKED_BOOT_COMPLETED) return
        val app = context.applicationContext
        if (!app.getSharedPreferences("honda_obd_boot", Context.MODE_PRIVATE)
                .getBoolean("autostart_enabled", true)) return
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                if (ObdHolder.autoConnect(app)) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        app.startForegroundService(Intent(app, ObdConnectionService::class.java))
                    } else {
                        app.startService(Intent(app, ObdConnectionService::class.java))
                    }
                }
            } catch (_: Throwable) {
                // The dashboard reports the cause on next open; never steal foreground focus.
            } finally {
                pending.finish()
            }
        }
    }
}
