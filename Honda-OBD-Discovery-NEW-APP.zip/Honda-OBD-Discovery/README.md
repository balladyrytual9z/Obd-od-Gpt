# OBD2 Dashboard

Android app for reading diagnostic trouble codes and monitoring live engine
parameters over a Bluetooth LE OBD2 adapter (built for the vgate iCar2 BLE,
works with ELM327-compatible clones). Inspired by Car Scanner ELM OBD2.

## Features (MVP)

- **DTC diagnostics** — read stored / pending / permanent trouble codes
  (modes 03 / 07 / 0A) with descriptions, clear codes (mode 04). Each code opens
  onto its own screen: when the app first and last saw it, which codes appeared
  near it and in what order, the ECU freeze frame, and — when the app was
  watching at the time — the ±30 s of engine data around the moment it appeared
- **Live dashboard** — one hero card for revs, road speed and the estimated gear,
  then a list of values with the range each one is normal in; tap any row for its
  last minute plotted against that range
- **Charts** — any parameter from the catalogue, up to six at once, in three axis
  modes: a strip each, one shared 0–100 % axis, or one shared axis in units
- **Vehicle profile** — kept against the car's VIN rather than the dongle, so one
  adapter moved between two cars is two profiles. The marque and country of assembly
  are decoded from the VIN by a bundled table, offline, with nothing leaving the
  phone; the model year is worked out from it and marked as worked out, because the
  year character repeats every thirty years. The driver adds the fuel type — which
  is what the air-flow reading is divided by to become consumption, and without
  which a diesel reads about 80 % high — plus displacement, rated power, kerb mass
  and tank capacity, which are stored against the car for later screens and are not
  read by anything yet
- **Trips** — every recording read back into distance, consumption, maxima and
  the events worth a badge (oil over its limit, the limiter reached), each with
  the second it happened; export as CSV. Distance and consumption are integrals of
  what the car reported rather than readings of anything, so both are shown as
  estimates, and any stretch the recording could not account for is stated
- **Says what it does not know** — every number the app worked out rather than read
  carries a `~` on the tile, in the chart legend and in the CSV header, and the
  detail sheet names the constant behind it: the assumed sea-level pressure behind
  a boost figure on a car without PID 33, the assumed petrol behind a consumption
  figure on a profile with no fuel type. Readings are dated by their own inputs, so
  a value whose source has gone quiet dims instead of being restamped as fresh
- **UI in English and Polish**

Planned later: Android Auto screen with live engine parameters
(via `androidx.car.app` — see `docs/research-android-stack.md` for the
distribution constraints that apply to sideloaded builds).

## Tech

Kotlin + Jetpack Compose, platform BLE API, coroutines/Flow.
minSdk 26, targetSdk 35.

```
app/src/main/java/com/miskibin/obd2dashboard/
├── ble/    BLE transport: scanner, GATT auto-probe, ELM327 byte stream
├── obd/    pure-JVM protocol layer: ELM327 session, PIDs, DTC, scheduler
├── data/   persistence: tile config, trip logs, per-vehicle cache
└── ui/     Compose screens: dashboard, DTC, charts, settings
```

## Building

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Every push builds an APK in GitHub Actions (artifact `obd2-dashboard-apk`);
tags matching `v*` publish a GitHub Release with a direct APK download link.
All builds share one checked-in debug signing key, so a newer APK installs
over an older one without uninstalling.

## Research notes

- `docs/research-obd2-protocol.md` — ELM327 AT layer, iCar2 BLE GATT
  profiles, mode 01 PID formulas, DTC decoding, throughput engineering
- `docs/research-vehicle-metadata.md` — what the app can know about the car
  beyond the OBD port: VIN decoding offline vs. online, the CEPiK and EEA open
  datasets, and the per-car constants that make the live numbers mean something
- `docs/research-android-stack.md` — stack choice rationale, Android Auto
  reality check, CI/signing setup, prior art (ObdGraphs, AndrOBD, …)

## Honda OBD Discovery custom build

The customized package in this branch builds two installable APKs:

- `app/build/outputs/apk/debug/app-debug.apk` — Honda OBD Discovery.
- `dtcclear/build/outputs/apk/debug/dtcclear-debug.apk` — Kasuj DTC, a separate launcher app.

Install the main app first, then `Kasuj DTC`. Both APKs use the same checked-in debug signing key so the signature-protected command channel can accept the clear request. The standalone utility sends a signed request to the main app; the main app remains the sole owner of the BLE/ELM327 connection.

The GitHub Actions workflow runs unit tests and uploads both APKs as one artifact. Hardware-specific behavior still needs testing on the ESSGOO head unit and the actual BLE adapter.
