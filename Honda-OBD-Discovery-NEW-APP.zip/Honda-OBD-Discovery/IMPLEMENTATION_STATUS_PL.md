# Honda OBD Discovery — stan implementacji

## Zmiany wprowadzone w tym pakiecie

- Zmieniono rzeczywistą paletę UI na grafit/czerń + miętowy akcent i bursztynowe ostrzeżenia.
- Na szerokich ekranach (w tym ESSGOO 1280×720) nawigacja główna używa stałego lewego paska inspirowanego CarPlay; na wąskich ekranach zostaje dolna nawigacja.
- Nazwa głównej pozycji launchera: `Honda OBD Discovery`.
- Przycisk kasowania DTC w głównej aplikacji wykonuje operację od razu, bez arkusza potwierdzenia i ostrzeżenia.
- Dodano osobny moduł Android `:dtcclear`, czyli oddzielny APK `com.honda.obddtcclear` z własną ikoną, nazwą i aktywnością `Kasuj DTC`.
- Oddzielny APK wysyła podpisane żądanie do `DtcClearCommandReceiver` w głównej aplikacji. Główny proces wykonuje Mode 04 przez istniejący `ObdHolder`/`ConnectionManager`; nie powstaje drugi kanał BLE.
- Po kliknięciu aplikacja próbuje użyć zapamiętanego adaptera, odczytuje diagnostykę ponownie i pokazuje wynik powiadomieniem. Samo wysłanie komendy nie jest uznawane za sukces.
- Dodano prawdziwy Android App Widget `Misfire Monitor` z połączeniem, RPM, ECT, wynikiem dostępnego testu misfire i miniwykresem RPM tworzonym wyłącznie z rzeczywistych próbek historii.
- Widget odświeża się przez istniejącą usługę połączenia i nie otwiera własnego kanału BLE.
- Dodano odbiornik `BOOT_COMPLETED`, który próbuje połączyć się z zapamiętanym adapterem bez otwierania aktywności na wierzchu, aby nie przejmować ekranu DiPlay/CarPlay.
- Dodano przełącznik automatycznego łączenia po starcie radia w ustawieniach.
- Zachowano istniejący silnik diagnostyczny, skaner PID, komunikację ELM327, historię, wykresy, raporty, logikę pojazdu i mechanizm automatycznego ponawiania połączenia.
- Zwiększono wersję projektu do `0.6.0-honda`.

## Co wymaga kompilacji i testu

W tym środowisku nie udało się uruchomić Gradle: wrapper wymaga pobrania Gradle 8.14.3 z `services.gradle.org`, a środowisko nie ma połączenia DNS z tym hostem. Nie oznacza to błędu kodu, ale oznacza, że **nie mogę uczciwie potwierdzić kompilacji**.

Po wypchnięciu projektu do GitHub Actions workflow uruchamia testy jednostkowe i buduje `app-debug.apk`. Po kompilacji należy sprawdzić na ESSGOO:

1. instalację APK i zachowanie istniejącego połączenia BLE;
2. wygląd i działanie lewego paska w 1280×720;
3. widoczność obu pozycji launchera;
4. kasowanie DTC bez potwierdzenia i treść powiadomienia przy sukcesie/błędzie;
5. dodanie widżetu do launchera i aktualizację podczas aktywnej sesji;
6. ponowne połączenie po uśpieniu/wybudzeniu oraz start systemu bez przejmowania pierwszego planu.

## Ograniczenia

- `Kasuj DTC` jest osobnym APK, ale operację diagnostyczną wykonuje główna aplikacja przez podpisane żądanie broadcast. Oba APK muszą być zainstalowane i podpisane tym samym certyfikatem, aby zadziałało uprawnienie signature-level.
- Widget pokazuje licznik misfire tylko wtedy, gdy dostępne wyniki Mode $06 dają się odczytać i zdekodować. Nie generuje syntetycznych liczników cylindrów.
- Autostart zależy od firmware'u i zarządzania energią ESSGOO. Odbiornik nie może zagwarantować działania po wymuszonym zatrzymaniu aplikacji przez system.
- Widżet aktualizuje się co około 5 sekund, gdy działa usługa połączenia. Bez aktywnej usługi widżet nie może obiecać ciągłych pomiarów.
- Nie potwierdzono jeszcze działania na fizycznym radiu ani zgodności z konkretną wersją adaptera ELM327 BLE.
