package com.miskibin.obd2dashboard.data

import com.miskibin.obd2dashboard.obd.Pids
import com.miskibin.obd2dashboard.obd.Reading
import com.miskibin.obd2dashboard.obd.VehicleSnapshot
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TripDeadbandTest {
    private fun snapshot(temp: Double, rpm: Double = 900.0) = VehicleSnapshot(
        readings = mapOf(
            Pids.COOLANT_TEMP to Reading(Pids.COOLANT_TEMP, "Coolant", "°C", temp, 1_000),
            Pids.ENGINE_RPM to Reading(Pids.ENGINE_RPM, "RPM", "rpm", rpm, 1_000),
        ),
    )

    @Test fun `ignores tiny repeated fluctuations before heartbeat`() {
        assertFalse(TripDeadband.shouldRecord(snapshot(90.0), snapshot(90.1), 1_000))
    }

    @Test fun `records meaningful changes`() {
        assertTrue(TripDeadband.shouldRecord(snapshot(90.0), snapshot(91.0), 1_000))
    }

    @Test fun `writes heartbeat for a stable parameter`() {
        assertTrue(TripDeadband.shouldRecord(snapshot(90.0), snapshot(90.0), TripDeadband.HEARTBEAT_MILLIS))
    }
}
