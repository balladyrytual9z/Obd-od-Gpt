package com.miskibin.obd2dashboard

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import android.content.pm.PackageManager
import android.os.Build
import com.miskibin.obd2dashboard.ble.ConnectionIssue
import com.miskibin.obd2dashboard.ble.ConnectionState
import com.miskibin.obd2dashboard.ble.ConnectionManager
import com.miskibin.obd2dashboard.ble.DeviceKind
import com.miskibin.obd2dashboard.ble.DiscoveredDevice
import com.miskibin.obd2dashboard.ble.ExtendedMemory
import com.miskibin.obd2dashboard.data.AppPreferences
import com.miskibin.obd2dashboard.data.ExtendedSupport
import com.miskibin.obd2dashboard.data.Garage
import com.miskibin.obd2dashboard.log.LogTag
import com.miskibin.obd2dashboard.log.ObdLog
import com.miskibin.obd2dashboard.data.MetricHistory
import com.miskibin.obd2dashboard.data.LiveDataArchive
import com.miskibin.obd2dashboard.data.MonitorSnapshot
import com.miskibin.obd2dashboard.data.SessionKind
import com.miskibin.obd2dashboard.data.TripRecorder
import com.miskibin.obd2dashboard.data.TripRepository
import com.miskibin.obd2dashboard.data.VinDecoder
import com.miskibin.obd2dashboard.obd.ExtendedProbe
import com.miskibin.obd2dashboard.service.AlertMonitor
import com.miskibin.obd2dashboard.widget.MisfireMonitorWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Process-wide owner of the connection.
 *
 * The UI and [com.miskibin.obd2dashboard.service.ObdConnectionService] must talk to the
 * *same* [ConnectionManager] — a second one would open a second GATT link to a dongle
 * that only accepts one. A plain singleton is enough here; a DI container would be
 * ceremony around a single object graph that never varies.
 */
@SuppressLint("StaticFieldLeak") // Everything here is built from the Application context.
object ObdHolder {

    val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var connection: ConnectionManager
        private set
    lateinit var preferences: AppPreferences
        private set
    lateinit var history: MetricHistory
        private set
    lateinit var recorder: TripRecorder
        private set
    lateinit var trips: TripRepository
        private set
    lateinit var alerts: AlertMonitor
        private set

    private var installed = false
    private lateinit var appContext: Context

    fun install(application: Application) {
        if (installed) return
        installed = true
        appContext = application.applicationContext
        connection = ConnectionManager(application, scope)
        preferences = AppPreferences(application)
        history = MetricHistory()
        recorder = TripRecorder(application, scope)
        trips = TripRepository(application)
        alerts = AlertMonitor(
            context = application,
            scope = scope,
            rules = preferences.alertRules,
            snapshots = connection.snapshot,
        )

        scope.launch { connection.snapshot.collect(history::record) }
        scope.launch { preferences.pollingEnabled.collect(connection::setPollingEnabled) }

        // Configurable automatic DTC refresh. Reads use ConnectionManager's scheduler lock,
        // so they never create a second BLE owner; the selected interval is a target cadence.
        scope.launch {
            combine(connection.state, preferences.dtcIntervalSeconds) { state, seconds -> state to seconds }
                .collectLatest { (state, seconds) ->
                    if (state is ConnectionState.Connected && !state.demo) {
                        while (true) {
                            delay(seconds * 1000L)
                            runCatching { connection.refreshDiagnostics() }
                        }
                    }
                }
        }

        // Public, versioned integration feed for companion apps. Consumers should register a
        // runtime BroadcastReceiver while active; payload includes only actual snapshot values.
        scope.launch {
            var lastSent = 0L
            connection.snapshot.collect { snapshot ->
                val now = System.currentTimeMillis()
                if (now - lastSent < 500L) return@collect
                lastSent = now
                runCatching { MisfireMonitorWidget.updateAll(appContext) }
                val readings = JSONArray()
                snapshot.readings.values.forEach { r ->
                    readings.put(JSONObject().put("key", r.key).put("name", r.name)
                        .put("value", r.value).put("unit", r.unit).put("timestampMillis", r.timestampMillis)
                        .put("quality", if (now - r.timestampMillis > 5000L) "STALE" else "LIVE"))
                }
                snapshot.extended.values.forEach { r ->
                    readings.put(JSONObject().put("key", "extended:${r.id}").put("name", r.id)
                        .put("value", r.value).put("unit", r.unit).put("timestampMillis", r.timestampMillis)
                        .put("quality", if (now - r.timestampMillis > 5000L) "STALE" else "LIVE"))
                }
                snapshot.derived.forEach { (id, value) ->
                    readings.put(JSONObject().put("key", "derived:$id").put("name", id)
                        .put("value", value.value).put("unit", "").put("timestampMillis", value.timestampMillis)
                        .put("quality", if (now - value.timestampMillis > 5000L) "STALE_${value.provenance.name}" else value.provenance.name).put("provenance", value.provenance.name))
                }
                val diagnostics = connection.diagnostics.value
                val dtcs = JSONArray()
                diagnostics?.all.orEmpty().forEach { dtc ->
                    dtcs.put(JSONObject().put("code", dtc.code).put("kind", dtc.kind.name))
                }
                val supported = JSONArray()
                connection.supportedPids.value.sorted().forEach { supported.put(it) }
                val undecoded = JSONArray()
                connection.undecodedPids.value.sorted().forEach { undecoded.put(it) }
                val monitors = JSONArray()
                connection.monitors.value?.tests.orEmpty().forEach { test ->
                    monitors.put(JSONObject().put("mid", test.mid).put("tid", test.tid)
                        .put("value", test.value).put("minimum", test.min).put("maximum", test.max)
                        .put("passed", test.passed).put("kind", test.kind.name).put("cylinder", test.cylinder))
                }
                val readinessMonitors = JSONArray()
                diagnostics?.monitorStatus?.readiness?.monitors.orEmpty().forEach { monitor ->
                    readinessMonitors.put(JSONObject().put("id", monitor.id.name).put("state", monitor.state.name))
                }
                val freeze = JSONObject()
                connection.freezeFrame.value?.values?.forEach { (pid, value) -> freeze.put(pid.toString(), value) }
                val performance = JSONObject()
                connection.performance.value?.let { track ->
                    performance.put("obdConditions", track.obdConditions ?: JSONObject.NULL)
                        .put("ignitionCycles", track.ignitionCycles ?: JSONObject.NULL)
                    val tracked = JSONArray()
                    track.monitors.forEach { count ->
                        tracked.put(JSONObject().put("monitor", count.monitor.name)
                            .put("completions", count.completions).put("conditions", count.conditions)
                            .put("ratio", count.ratio ?: JSONObject.NULL).put("neverRun", count.neverRun))
                    }
                    performance.put("monitors", tracked)
                }
                val payload = JSONObject().put("schemaVersion", 2).put("emittedAtMillis", now)
                    .put("snapshotUpdatedAtMillis", snapshot.updatedAtMillis)
                    .put("vehicle", JSONObject().put("profile", "Honda Civic VIII UFO hatchback, rok 2010, silnik L13Z1 1.4 i-VTEC 100 KM, skrzynia manualna, napęd FWD, opony 205/55 R16")
                        .put("make", "Honda").put("model", "Civic VIII UFO hatchback").put("year", 2010)
                        .put("engineCode", "L13Z1").put("engine", "1.4 i-VTEC").put("powerHp", 100)
                        .put("transmission", "manualna").put("drive", "FWD").put("tireSize", "205/55 R16")
                        .put("vin", connection.vin.value ?: JSONObject.NULL).put("sessionKind", connection.sessionKind.value.name))
                    .put("connection", connection.state.value.javaClass.simpleName)
                    .put("batteryVoltage", snapshot.batteryVoltage ?: JSONObject.NULL)
                    .put("batteryAtMillis", snapshot.batteryAtMillis)
                    .put("readings", readings).put("dtcs", dtcs).put("mode06", monitors)
                    .put("supportedPids", supported).put("undecodedPids", undecoded)
                    .put("readiness", JSONObject().put("milOn", diagnostics?.monitorStatus?.milOn ?: JSONObject.NULL)
                        .put("dtcCount", diagnostics?.monitorStatus?.dtcCount ?: JSONObject.NULL)
                        .put("monitors", readinessMonitors))
                    .put("freezeFrame", freeze).put("performanceTracking", performance)
                runCatching { LiveDataArchive.append(appContext, payload) }
                appContext.sendBroadcast(Intent("com.miskibin.obd2dashboard.LIVE_DATA")
                    .setPackage(null).putExtra("schemaVersion", 2).putExtra("payloadJson", payload.toString()))
            }
        }

        // The connection layer decides *what* to probe and *when*; where the answers are
        // kept is none of its business, so the two are wired together here.
        connection.extendedMemory = object : ExtendedMemory {
            override suspend fun known(vin: String): Map<String, ExtendedProbe> =
                ExtendedSupport.forVin(
                    preferences.extendedSupport(connection.sessionKind.value).first(),
                    vin,
                )

            override suspend fun remember(vin: String, id: String, probe: ExtendedProbe) {
                preferences.rememberExtendedProbe(connection.sessionKind.value, vin, id, probe)
            }
        }
        // Which generation of a car it is decides which module its tyre pressures live in,
        // and the only offline source for that is the VIN's model-year character.
        connection.modelYear = { vin -> VinDecoder.decode(vin)?.modelYear }

        // One reading of the on-board monitors per connection, filed under the car it came
        // from. Both halves have to be present — a snapshot with no VIN belongs to no car
        // and would be indistinguishable from the next one.
        scope.launch {
            combine(connection.vin, connection.monitors, connection.performance) { vin, tests, ipt ->
                if (vin == null) null else MonitorSnapshot(
                    vin = vin,
                    capturedAtMillis = tests?.capturedAtMillis ?: System.currentTimeMillis(),
                    tests = tests?.tests.orEmpty(),
                    performance = ipt,
                )
            }.collect { snapshot ->
                if (snapshot != null && !snapshot.isEmpty) {
                    preferences.recordMonitorSnapshot(connection.sessionKind.value, snapshot)
                }
            }
        }
        // Changing cars ends the recording and drops the traces the old one left behind:
        // the simulation's last ten minutes must not appear on the chart of a real drive,
        // and a recording started in demo mode must not go on collecting real values.
        scope.launch {
            // Only actual changes: the first value is the car the app started on.
            connection.sessionKind.drop(1).collect { kind ->
                recorder.stopIfCarChanged(kind)
                history.clear()
            }
        }
        // The fuel maths runs inside the polling loop, which has no idea which car it is
        // talking to; this is the one wire that tells it. All three sides move — the VIN
        // when a session opens, the garage when the profile is edited, the kind when demo
        // mode is entered — so it is a combine rather than a read at connect time, and
        // editing the profile changes the gauges at once.
        scope.launch {
            combine(
                connection.sessionKind,
                connection.vin,
                preferences.vehicles(SessionKind.Real),
                preferences.vehicles(SessionKind.Demo),
            ) { kind, vin, real, demo ->
                // Passed on unfilled rather than defaulted here: the consumption maths falls
                // back to petrol on its own, and the extended table needs to be able to tell
                // "the driver said petrol" from "the driver has not said", because it only
                // asks a car about its particulate filter when it has been told there is one.
                Garage.find(if (kind.demo) demo else real, vin)?.fuel
            }.collect(connection::setFuelType)
        }
        alerts.start()
    }

    /**
     * Reconnects to the remembered adapter without asking anything of the driver — the
     * app is normally launched already sitting in a mount with the dongle plugged in.
     *
     * A missing permission is reported rather than returned as a bare `false`: silently
     * doing nothing here is how the app ends up looking broken to somebody who revoked
     * Bluetooth access in system settings and has no idea that is what they did.
     */
    suspend fun autoConnect(context: Context): Boolean {
        val saved = preferences.savedAdapter.first() ?: return false
        if (!hasConnectPermission(context)) {
            ObdLog.log(LogTag.CONN, "auto-connect skipped: BLUETOOTH_CONNECT not granted")
            connection.reportSetupIssue(
                ConnectionIssue.ConnectPermission,
                "BLUETOOTH_CONNECT not granted",
            )
            return false
        }
        ObdLog.log(
            LogTag.CONN,
            "auto-connecting to ${saved.address} (${if (saved.classic) "classic" else "LE"})",
        )
        connection.connect(
            DiscoveredDevice(
                address = saved.address,
                name = saved.name,
                rssi = 0,
                looksLikeAdapter = true,
                kind = if (saved.classic) DeviceKind.Classic else DeviceKind.Le,
                bonded = saved.classic,
            ),
        )
        return true
    }

    fun hasConnectPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
}
