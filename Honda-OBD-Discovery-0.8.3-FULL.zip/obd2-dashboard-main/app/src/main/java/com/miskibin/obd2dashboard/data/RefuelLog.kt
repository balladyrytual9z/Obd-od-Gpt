package com.miskibin.obd2dashboard.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** User-entered refuelling records. Consumption is only computed across full-to-full pairs. */
data class RefuelEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestampMillis: Long,
    val odometerKm: Double,
    val litres: Double,
    val totalCost: Double,
    val fullTank: Boolean,
    val note: String = "",
)

object RefuelLog {
    private const val PREFS = "honda_obd_refuels"
    private const val KEY = "entries_v1"

    fun all(context: Context): List<RefuelEntry> = runCatching {
        val array = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
        (0 until array.length()).mapNotNull { i -> array.optJSONObject(i)?.let(::decode) }
            .sortedBy(RefuelEntry::odometerKm)
    }.getOrDefault(emptyList())

    fun add(context: Context, entry: RefuelEntry) {
        val entries = all(context).toMutableList()
        entries.removeAll { it.id == entry.id }
        entries += entry
        val array = JSONArray()
        entries.sortedBy(RefuelEntry::timestampMillis).forEach { e -> array.put(encode(e)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    fun delete(context: Context, id: String) {
        val array = JSONArray()
        all(context).filterNot { it.id == id }.forEach { array.put(encode(it)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    /** Last two full-tank events with intervening purchases; null if odometer data is invalid. */
    fun latestFullToFull(context: Context): Pair<Double, Double>? {
        val full = all(context).filter { it.fullTank }.sortedBy(RefuelEntry::odometerKm)
        if (full.size < 2) return null
        val previous = full[full.lastIndex - 1]
        val current = full.last()
        val distance = current.odometerKm - previous.odometerKm
        if (distance <= 0.0) return null
        val litres = all(context).filter { it.odometerKm > previous.odometerKm && it.odometerKm <= current.odometerKm }
            .sumOf(RefuelEntry::litres)
        return distance to (litres / distance * 100.0)
    }

    private fun encode(e: RefuelEntry) = JSONObject().put("id", e.id).put("timestampMillis", e.timestampMillis)
        .put("odometerKm", e.odometerKm).put("litres", e.litres).put("totalCost", e.totalCost)
        .put("fullTank", e.fullTank).put("note", e.note)

    private fun decode(o: JSONObject) = RefuelEntry(
        id = o.optString("id", UUID.randomUUID().toString()), timestampMillis = o.optLong("timestampMillis"),
        odometerKm = o.optDouble("odometerKm", Double.NaN), litres = o.optDouble("litres", Double.NaN),
        totalCost = o.optDouble("totalCost", Double.NaN), fullTank = o.optBoolean("fullTank"), note = o.optString("note"),
    ).takeIf { it.odometerKm.isFinite() && it.litres > 0 && it.totalCost >= 0 }
}
