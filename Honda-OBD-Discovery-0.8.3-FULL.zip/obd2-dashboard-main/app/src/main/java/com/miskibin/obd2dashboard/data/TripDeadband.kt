package com.miskibin.obd2dashboard.data

import com.miskibin.obd2dashboard.obd.VehicleSnapshot
import kotlin.math.abs

/**
 * Reduces redundant trip-log rows without allowing a stationary value to disappear from a
 * long trip. A heartbeat row is retained at least every five seconds, and a newly available
 * or removed metric always creates a row.
 */
internal object TripDeadband {
    const val HEARTBEAT_MILLIS = 5_000L

    fun shouldRecord(previous: VehicleSnapshot?, current: VehicleSnapshot, elapsedMillis: Long): Boolean {
        if (previous == null || elapsedMillis >= HEARTBEAT_MILLIS) return true
        val before = values(previous)
        val after = values(current)
        if (before.keys != after.keys) return true
        return after.any { (key, value) ->
            val old = before[key] ?: return@any true
            abs(value - old) >= threshold(key)
        }
    }

    private fun values(snapshot: VehicleSnapshot): Map<String, Double> = buildMap {
        snapshot.readings.forEach { (key, reading) -> put("pid:$key", reading.value) }
        snapshot.derived.forEach { (key, value) -> put("derived:$key", value.value) }
        snapshot.extended.forEach { (key, value) -> put("extended:$key", value.value) }
        snapshot.batteryVoltage?.let { put("batteryVoltage", it) }
    }

    private fun threshold(key: String): Double = when {
        key == "batteryVoltage" -> 0.03
        key.startsWith("pid:") -> 0.25 // generic conservative threshold; raw values remain unchanged
        key.startsWith("extended:") -> 0.25
        else -> 0.1
    }
}
