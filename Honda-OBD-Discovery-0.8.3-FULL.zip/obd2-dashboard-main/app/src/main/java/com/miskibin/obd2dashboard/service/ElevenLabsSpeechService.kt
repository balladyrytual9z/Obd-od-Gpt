package com.miskibin.obd2dashboard.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.miskibin.obd2dashboard.MainActivity
import com.miskibin.obd2dashboard.R
import com.miskibin.obd2dashboard.data.ElevenLabsSecret
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Foreground playback service: speech survives leaving/closing the settings screen. */
class ElevenLabsSpeechService : Service() {
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var player: MediaPlayer? = null
    private var audioFile: File? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopPlayback()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification("Przygotowuję syntezę mowy…"))
        val text = intent?.getStringExtra(EXTRA_TEXT).orEmpty()
        val voiceId = intent?.getStringExtra(EXTRA_VOICE_ID).orEmpty()
        if (text.isBlank() || voiceId.isBlank()) {
            updateNotification("Brak tekstu raportu lub wybranego głosu")
            stopSelf()
            return START_NOT_STICKY
        }
        serviceScope.launch {
            try {
                val token = ElevenLabsSecret.load(this@ElevenLabsSpeechService)
                    ?: throw IllegalStateException("Brak zapisanego klucza ElevenLabs")
                val chunks = splitText(text)
                chunks.forEachIndexed { index, chunk ->
                    updateNotification("Generuję audio ${index + 1}/${chunks.size}…")
                    val file = withContext(Dispatchers.IO) { synthesize(token, voiceId, chunk) }
                    audioFile = file
                    updateNotification("Czytam raport: część ${index + 1}/${chunks.size}")
                    playAndAwait(file)
                    file.delete()
                    audioFile = null
                }
                updateNotification("Raport został przeczytany")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                updateNotification("Błąd mowy: ${(e.message ?: e.javaClass.simpleName).take(100)}")
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    private fun synthesize(token: String, voiceId: String, text: String): File {
        var conn: HttpURLConnection? = null
        try {
            conn = (URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20000
                readTimeout = 120000
                doOutput = true
                setRequestProperty("xi-api-key", token)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "audio/mpeg")
            }
            val body = JSONObject()
                .put("text", text)
                .put("model_id", "eleven_multilingual_v2")
                .put("voice_settings", JSONObject().put("stability", 0.5).put("similarity_boost", 0.75))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val detail = runCatching { conn.errorStream?.bufferedReader()?.use { it.readText() } }.getOrNull().orEmpty()
                throw IllegalStateException("ElevenLabs HTTP $code ${detail.take(180)}")
            }
            val file = File(cacheDir, "elevenlabs_report_${System.currentTimeMillis()}.mp3")
            conn.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            if (file.length() < 100) { file.delete(); throw IllegalStateException("Pusta odpowiedź audio") }
            return file
        } finally { conn?.disconnect() }
    }

    private suspend fun playAndAwait(file: File) = suspendCancellableCoroutine<Unit> { continuation ->
        val mp = MediaPlayer()
        player = mp
        mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        mp.setOnCompletionListener {
            stopPlayerOnly()
            if (continuation.isActive) continuation.resume(Unit)
        }
        mp.setOnErrorListener { _, what, extra ->
            stopPlayerOnly()
            if (continuation.isActive) continuation.resumeWithException(IllegalStateException("Błąd audio ($what/$extra)"))
            true
        }
        continuation.invokeOnCancellation { stopPlayerOnly() }
        try {
            mp.setDataSource(file.absolutePath)
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
        } catch (e: Exception) {
            stopPlayerOnly()
            if (continuation.isActive) continuation.resumeWithException(e)
        }
    }

    /** Keep every part of a long report; split on whitespace and prefer paragraph boundaries. */
    private fun splitText(text: String, maxChars: Int = 4200): List<String> {
        val normalized = text.trim()
        if (normalized.length <= maxChars) return listOf(normalized)
        val paragraphs = normalized.split(Regex("\\n\\s*\\n"))
        val result = mutableListOf<String>()
        var current = StringBuilder()
        for (paragraph in paragraphs) {
            var remaining = paragraph.trim()
            while (remaining.length > maxChars) {
                val splitAt = remaining.lastIndexOf(' ', maxChars).takeIf { it > maxChars / 2 } ?: maxChars
                val part = remaining.substring(0, splitAt).trim()
                if (part.isNotEmpty()) result += part
                remaining = remaining.substring(splitAt).trim()
            }
            if (remaining.isNotEmpty()) {
                if (current.isNotEmpty() && current.length + remaining.length + 2 > maxChars) {
                    result += current.toString()
                    current = StringBuilder()
                }
                if (current.isNotEmpty()) current.append("\n\n")
                current.append(remaining)
            }
        }
        if (current.isNotEmpty()) result += current.toString()
        return result.ifEmpty { listOf(normalized) }
    }

    private fun stopPlayback() {
        serviceScope.coroutineContext.cancel()
        stopPlayerOnly()
        audioFile?.delete()
        audioFile = null
    }

    private fun stopPlayerOnly() {
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Czytanie raportów OBD", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Stan syntezy i odtwarzania raportów diagnostycznych"
                setSound(null, null)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(status: String): Notification {
        val openIntent = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(this, 2, Intent(this, ElevenLabsSpeechService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Honda OBD • czytanie raportu")
            .setContentText(status)
            .setContentIntent(openIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .addAction(0, "Zatrzymaj", stopIntent)
            .build()
    }

    private fun updateNotification(status: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(status))
    }

    override fun onDestroy() {
        stopPlayerOnly()
        serviceScope.cancel()
        audioFile?.delete()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.miskibin.obd2dashboard.action.STOP_ELEVENLABS"
        const val EXTRA_TEXT = "report_text"
        const val EXTRA_VOICE_ID = "voice_id"
        private const val CHANNEL_ID = "honda_obd_report_speech"
        private const val NOTIFICATION_ID = 7124
    }
}
