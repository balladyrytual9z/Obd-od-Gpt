package com.miskibin.obd2dashboard.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.miskibin.obd2dashboard.ObdHolder
import com.miskibin.obd2dashboard.R
import com.miskibin.obd2dashboard.data.Metrics
import com.miskibin.obd2dashboard.data.valueOf
import com.miskibin.obd2dashboard.data.worstMisfire

/** Real home-screen AppWidget; displays actual latest snapshot, or explicit unavailable states. */
class MisfireMonitorWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val snapshot = runCatching { ObdHolder.connection.snapshot.value }.getOrNull()
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_misfire_monitor)
            val rpm = snapshot?.valueOf(Metrics.Rpm)
            val ect = snapshot?.valueOf(Metrics.CoolantTemp)
            views.setTextViewText(R.id.widget_rpm, rpm?.let { "${it.toInt()} rpm" } ?: "RPM: brak danych")
            views.setTextViewText(R.id.widget_ect, ect?.let { "ECT ${it.toInt()} °C" } ?: "ECT: brak danych")
            val misfire = runCatching { ObdHolder.connection.monitors.value.worstMisfire() }.getOrNull()
            views.setTextViewText(R.id.widget_misfire_status, misfire?.let { "Mode 06 misfire: ${it.count} · ${if (it.passed) "PASS" else "FAIL"}" } ?: "Misfire: brak obsługiwanych danych Mode 06")
            views.setTextViewText(R.id.widget_updated, snapshot?.updatedAtMillis?.takeIf { it > 0 }?.let { "Pomiar: ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(it))}" } ?: "Brak aktualnego pomiaru")
            manager.updateAppWidget(id, views)
        }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(android.content.ComponentName(context, MisfireMonitorWidget::class.java))
            if (ids.isNotEmpty()) MisfireMonitorWidget().onUpdate(context, manager, ids)
        }
    }
}
