package com.miskibin.obd2dashboard.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.miskibin.obd2dashboard.DtcClearActivity
import com.miskibin.obd2dashboard.R

class DtcClearWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_dtc_clear)
            val intent = Intent(context, DtcClearActivity::class.java).setAction(DtcClearActivity.ACTION_CLEAR)
            val pending = PendingIntent.getActivity(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_clear_button, pending)
            manager.updateAppWidget(id, views)
        }
    }
    companion object { fun refresh(context: Context) { AppWidgetManager.getInstance(context).let { it.notifyAppWidgetViewDataChanged(it.getAppWidgetIds(ComponentName(context, DtcClearWidget::class.java)), R.id.widget_clear_button) } } }
}
