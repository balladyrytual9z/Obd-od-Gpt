# Integracja danych OBD LIVE z inną aplikacją Android

## Interfejs

Podczas aktualizacji snapshotu aplikacja wysyła broadcast:

- Action: `com.miskibin.obd2dashboard.LIVE_DATA`
- Extra `schemaVersion`: `2`
- Extra `payloadJson`: JSON jako `String`
- Format danych: jeden snapshot z rzeczywiście odczytanymi parametrami, znacznikami czasu, jakością, kodami DTC, wynikami Mode 06, PID-ami obsługiwanymi i nierozkodowanymi oraz statusem połączenia.
- Częstotliwość: maksymalnie około 2 razy/s (throttle 500 ms), zależnie od tego, jak często zmienia się snapshot.

Broadcast jest wysyłany bez ograniczenia do konkretnego pakietu, aby inne aplikacje mogły go odebrać. To świadome udostępnienie danych pojazdu: aplikacje odbiorcze powinny rejestrować receiver tylko wtedy, gdy potrzebują danych, nie logować tokenów i jasno informować użytkownika o dalszym przekazywaniu danych. Nie zawiera klucza OpenRouter.

## Odbiornik Kotlin

```kotlin
private val obdReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "com.miskibin.obd2dashboard.LIVE_DATA") return
        val schema = intent.getIntExtra("schemaVersion", 1)
        val json = intent.getStringExtra("payloadJson") ?: return
        val payload = JSONObject(json)
        val readings = payload.optJSONArray("readings") ?: JSONArray()
        for (i in 0 until readings.length()) {
            val reading = readings.optJSONObject(i) ?: continue
            val key = reading.optString("key")
            val value = reading.optDouble("value", Double.NaN)
            val unit = reading.optString("unit")
            val quality = reading.optString("quality", "UNKNOWN")
            val timestamp = reading.optLong("timestampMillis")
            // Zapisz/wyświetl wartość tylko po sprawdzeniu quality i timestamp.
        }
        // Obsługuj dtcs, mode06, supportedPids, undecodedPids i connection opcjonalnie.
        // Ignoruj nieznane pola, aby zachować kompatybilność wsteczną.
    }
}

override fun onStart() {
    super.onStart()
    registerReceiver(obdReceiver, IntentFilter("com.miskibin.obd2dashboard.LIVE_DATA"))
}

override fun onStop() {
    runCatching { unregisterReceiver(obdReceiver) }
    super.onStop()
}
```

Dostosuj rejestrację receivera do poziomu API aplikacji odbiorczej. Na Androidzie 13+ użyj właściwego flagowania eksportu dla dynamicznego receivera. Na starszym Androidzie 9 radio docelowe używa API 28.

## Pola JSON schemaVersion 2

- `emittedAtMillis`, `snapshotUpdatedAtMillis`
- `vehicle.profile`, `vehicle.vin`, `vehicle.sessionKind`
- `connection`
- `batteryVoltage`, `batteryAtMillis` — napięcie raportowane przez adapter/warstwę OBD, nie gwarantowany pomiar napięcia na zaciskach akumulatora
- `readings[]`: `key`, `name`, `value`, `unit`, `timestampMillis`, `quality`; wartości pochodne dodatkowo mają `provenance`
- `dtcs[]`: `code`, `kind`
- `mode06[]`: `mid`, `tid`, `value`, `minimum`, `maximum`, `passed`, `kind`, `cylinder`
- `supportedPids[]`, `undecodedPids[]`
- `readiness.milOn`, `readiness.dtcCount`, `readiness.monitors[]`
- `freezeFrame`: mapowanie identyfikatora PID na wartość odczytaną z ramki zamrożonej (puste, gdy brak ramki)
- `performanceTracking`: liczniki `0908`, jeśli ECU je udostępnia

Jakość `LIVE` oznacza próbkę świeżą według progu pięciu sekund. Starsza próbka jest oznaczana `STALE` lub `STALE_*`; nie wolno traktować jej jako bieżącej. Parametry wyliczone mają pole `provenance` i nie powinny być przedstawiane jako bezpośredni odczyt ECU.

## Archiwum lokalne

Aplikacja zapisuje snapshoty do prywatnego pliku `files/obd-live-history.jsonl` (jeden JSON na linię). Plik nie ma automatycznej retencji ani limitu wieku. To nie jest surowy strumień bajtów BLE: zawiera zdekodowane snapshoty i dane diagnostyczne, które aplikacja w danym momencie udostępnia. Dane sprzed zainstalowania tej wersji nie zostaną odtworzone. Raport AI wysyła maksymalnie 250 ostatnich rekordów z wybranego zakresu, żeby ograniczyć wielkość żądania; lokalne archiwum pozostaje pełne.

## Diagnostyczne ograniczenia

Standardowy ELM327/OBD-II nie udostępnia wszystkich parametrów producenta. `undecodedPids` wskazuje PID-y znalezione przez mapę obsługi, dla których aplikacja nie ma dekodera. Brak pola nie oznacza wartości zero. Dane Mode 06 zależą od ECU i mogą nie być dostępne. Broadcast nie jest gwarantowanym trwałym kanałem transportowym; odbiorca powinien wykorzystywać własny timeout i oznaczać dane jako nieaktualne po braku nowych próbek.
