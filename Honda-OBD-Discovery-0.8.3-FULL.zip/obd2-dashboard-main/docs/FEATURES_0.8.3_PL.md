# Honda OBD Discovery 0.8.3 — pakiet optymalizacji

## Zawarte w źródłach

- Jeden centralny `PidScheduler`; widoki korzystają z publikowanego snapshotu, nie tworzą własnych równoległych pętli OBD.
- Szybkie/średnie/wolne tiery PID oraz rotacja wolnych PID-ów.
- Wieloparametrowe zapytania Mode 01 tylko po pomyślnym teście obsługi batcha.
- Odbiór odpowiedzi ELM do promptu `>` i składanie odpowiedzi wieloliniowych.
- Ograniczone czasowo zapytania Mode 06; odczyt diagnostyczny nie należy do normalnego szybkiego harmonogramu.
- Odpoczynek dla PID-ów zwracających wielokrotnie `NO DATA` oraz ponawianie po określonym czasie.
- Odrzucanie wartości fizycznie niemożliwych dla standardowych jednostek przed publikacją na dashboardzie.
- Deadband logowania trasy z heartbeatem co maksymalnie 5 s.
- Historia, CSV, zapis tankowań, diagnostyka DTC, freeze frame/readiness, wykresy, widgety i usługi głosowe istniejące w bazowym projekcie.
- Workflow GitHub Actions: testy, debug APK, artefakt z 90-dniową retencją i wersjonowane GitHub Releases.

## Nie należy przedstawiać jako gwarantowane

- 5–10 Hz rzeczywistego odświeżania każdego PID-u: zależy od adaptera, ECU, transportu i liczby aktywnych PID-ów.
- Składni multi-PID na każdym klonie ELM327: funkcja włącza się dopiero po pozytywnym teście odpowiedzi.
- Rzeczywistej prędkości przed korektą licznika, surowych ramek ABS/MICU, VTEC/VTC, ELD ani danych modułów producenta bez zweryfikowanego PID-u/ramki.
- Mocy i momentu jako pomiarów ECU, jeżeli są tylko wyliczane z masy i przyspieszenia.
- Przejęcia ekranu Android Auto przez alarmy. Host Android Auto ogranicza rodzaje i prezentację interfejsu.

## Publikowanie kolejnych wersji

Umieść nowy `Honda-OBD-Discovery-X.Y.Z-FULL.zip` w katalogu głównym repozytorium i workflow w `.github/workflows/android.yml`. Workflow wybierze najwyższą wersję semantyczną, uruchomi testy, zbuduje APK i zachowa źródła/APK w artefaktach oraz GitHub Releases. Każdy build ma unikalny `versionCode` i sufiks `+build.N` w `versionName`. Przy kolejnym wydaniu podnieś wersję w `app/build.gradle.kts` i nazwę ZIP-u.
