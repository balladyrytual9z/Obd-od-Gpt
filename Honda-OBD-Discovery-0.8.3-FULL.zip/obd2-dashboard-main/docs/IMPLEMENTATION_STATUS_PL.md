# Honda OBD Discovery — zakres tej paczki i status testów

## Zmiany w tej paczce

- Zachowano istniejący silnik `ConnectionManager`, `Obd2Client`, `PidScheduler` oraz transporty BLE/Classic; nowe funkcje korzystają z tego samego właściciela połączenia.
- Ustawiany w aplikacji interwał automatycznego odświeżania DTC: 1, 2, 5, 10, 15, 30, 60, 120 lub 300 sekund; domyślne 10 s. Odczyty są sekwencyjne i współdzielą blokadę schedulera.
- OpenRouter w ustawieniach: zapis klucza, pobieranie listy modeli, ręczne ID modelu lub wybór z listy, zakres raportu 15 min / 24 h / 7 dni / cała historia / własna liczba godzin oraz generowanie raportu z bieżącego snapshotu i próbek archiwalnych.
- Klucz API jest szyfrowany AES-GCM, a klucz szyfrujący znajduje się w Android Keystore. Nie jest to gwarancja ochrony na urządzeniu skompromitowanym.
- Archiwum LIVE zapisuje snapshoty jako JSONL w prywatnym katalogu aplikacji, bez automatycznego limitu retencji. Eksport archiwum odbywa się przez Android Sharesheet. Raport AI dołącza maksymalnie 250 ostatnich próbek z wybranego zakresu, aby ograniczyć wielkość żądania; lokalny plik nie jest w ten sposób obcinany.
- Broadcast `com.miskibin.obd2dashboard.LIVE_DATA`, schema v2, udostępnia wartości PID, parametry rozszerzone i pochodne, jakość i czas próbek, DTC, Mode 06, readiness, freeze frame, liczniki monitorów, VIN/profil, stan połączenia i listy PID obsługiwanych/nierozkodowanych. Opis integracji i kod odbiornika są w `docs/LIVE_DATA_INTEGRATION_PL.md`.
- Dodano lokalny dziennik tankowań: data, przebieg, litry, koszt, oznaczenie pełnego baku, lista ostatnich tankowań, eksport CSV oraz zużycie liczone metodą pełny bak–pełny bak, gdy istnieją co najmniej dwa prawidłowe punkty.
- Dodano receiver startu systemu i aktualizacji aplikacji, który prosi o uruchomienie usługi foreground i automatyczne połączenie z zapisanym adapterem. Android/ESSGOO nadal może ograniczyć uruchomienie w tle, np. przez ustawienia oszczędzania energii.
- Osobna aktywność launchera „Kasuj DTC” próbuje skasować błędy bez dodatkowego okna, ponownie odczytuje kody i zapisuje status. Wysłanie komendy nie jest samo w sobie traktowane jako potwierdzenie sukcesu.
- Manifest deklaruje dwa rzeczywiste Android App Widgets: Misfire Monitor i Kasuj DTC. Ich wyświetlanie zależy od obsługi widżetów przez launcher ESSGOO.
- Podniesiono wersję aplikacji do `0.7.0` / `versionCode 7`.

## Ograniczenia, które trzeba znać

- „Kasuj DTC” jest osobną aktywnością/pozycją launchera w tym samym APK, a nie osobnym pakietem. To pozwala współdzielić właściciela BLE.
- Broadcast emituje snapshot aplikacji, nie surowe ramki CAN/ELM ani wszystkie dane, jakie hipotetycznie potrafiłoby odczytać narzędzie producenta. PID-y nierozkodowane są raportowane oddzielnie.
- Interwał DTC 1 s jest wartością docelową. Czas odpowiedzi ECU, timeouty i współdzielenie łącza mogą wydłużyć realny cykl.
- Zużycie paliwa z tankowań jest obliczane wyłącznie z przebiegu i wpisanych litrów; nie jest kalibracją ECU. Błędny przebieg lub niepełne tankowania zafałszują wynik.
- Archiwum bezterminowe rośnie wraz z użyciem i może zajmować dużo miejsca. Usunięcie danych aplikacji usuwa również tę historię.
- Broadcast jest globalny, żeby inne aplikacje mogły go odbierać. Nie zawiera klucza API, ale zawiera dane pojazdu i diagnostyki; odbiorniki powinny działać tylko wtedy, gdy potrzebują danych.
- Napięcie przekazywane w feedzie jest wartością widzianą przez warstwę adaptera/OBD i nie musi być bezpośrednim pomiarem napięcia na zaciskach akumulatora.

## Weryfikacja

- Wykonano inspekcję kodu bazowego, kontrolę poprawności XML manifestu/zasobów oraz kontrolę składniową Kotlin bez pełnego classpath (nie zastępuje to kompilacji projektu).
- `./gradlew testDebugUnitTest assembleDebug` nie rozpoczął budowania: środowisko nie mogło rozwiązać `services.gradle.org` przez DNS i pobrać Gradle 8.14.3.
- **Nie potwierdzono kompilacji, przejścia testów jednostkowych ani działania na fizycznym radiu ESSGOO.** Należy uruchomić workflow GitHub Actions i przetestować APK na urządzeniu przed uznaniem nowych funkcji za zweryfikowane.


## ElevenLabs: odczyt raportu w tle (0.7.0)
- Dodano lokalny zapis klucza ElevenLabs jako AES-GCM z kluczem w Android Keystore.
- Ustawienia pobierają głosy z `GET /v1/voices`; użytkownik wybiera głos i zapisuje jego ID.
- Po wygenerowaniu raportu przycisk „Czytaj wygenerowany raport” wysyła tekst do `POST /v1/text-to-speech/{voice_id}` (model `eleven_multilingual_v2`) i odtwarza MP3 w usłudze pierwszoplanowej `mediaPlayback`.
- Usługa działa niezależnie od ekranu ustawień i utrzymuje powiadomienie z akcją „Zatrzymaj”. Odtwarzanie kończy usługę po przeczytaniu całości.
- Wymaga działającego Internetu i planu/kredytów ElevenLabs. Dłuższe raporty są dzielone na części po ok. 4 200 znaków i odtwarzane kolejno, bez celowego ucinania końcówki raportu. Nie zweryfikowano kompilacji Androida ani testu na fizycznym ESSGOO z powodu ograniczeń sieci/środowiska; funkcję trzeba potwierdzić buildem CI i testem urządzenia.


## Tryby głosowe AI (0.8.0)

- Dodano osobną sekcję ustawień „AI i głos”: klucz OpenRouter i model do komentarzy, klucz ElevenLabs i wybór głosu, dwa przełączniki trybów oraz wybór persony komentarza. Sekrety pozostają szyfrowane przez Android Keystore.
- **Alarmy głosowe** działają niezależnie od komentarzy. Reagują na nowo wykryte kody DTC i świeży odczyt temperatury płynu chłodzącego: ostrzeżenie od 110°C, alarm krytyczny od 115°C. To progi aplikacji, nie zastępują diagnostyki ani instrukcji producenta. Aplikacja nie udaje, że widzi ciśnienie oleju, ciśnienie opon lub stan hydrauliki hamulców, jeśli te dane nie są dostępne przez OBD.
- **Komentowanie sytuacji** ma trzy persony: Mechanik, Strażak i Eco-driving. Komentarz powstaje z bieżących, świeżych odczytów i kodów DTC przez wybrany model OpenRouter; przy braku odczytu prędkości lub gdy prędkość wynosi mniej niż 5 km/h komentarz nie jest inicjowany. Ograniczenie częstotliwości wynosi co najmniej 90 sekund.
- Usługa pierwszoplanowa odbiera broadcast LIVE także po przejściu do launchera. Powiadomienie pozwala wstrzymać/wznowić komentarze lub wyłączyć tryby. Opcja „Po wyjściu dokończ tylko bieżący komentarz” domyślnie blokuje rozpoczynanie nowych komentarzy w tle; alarmy pozostają aktywne.
- Komentarze i synteza wymagają dostępu do sieci, poprawnych kluczy i limitów OpenRouter/ElevenLabs. Usługa nie jest jeszcze potwierdzona testem na fizycznym ESSGOO: w tym środowisku Gradle nie mógł pobrać dystrybucji z powodu DNS (`services.gradle.org`). Progi i dane dostępne zależą od odczytów zwracanych przez konkretny adapter/ECU.

## Optymalizacje ELM327 / Civic VIII (0.8.3)

- TripRecorder stosuje filtr deadband: nie zapisuje kolejnego wiersza, gdy wszystkie dostępne wartości są niemal niezmienione; zachowuje wiersz heartbeat co 5 s, a pojawienie/zanik metryki zawsze wymusza zapis. Surowe wartości nie są zaokrąglane ani modyfikowane.
- Scheduler odrzuca wartości dekodowane poza szerokimi granicami fizycznymi dla standardowych jednostek (RPM, km/h, °C, V, kPa, %, wyprzedzenie zapłonu, lambda). Nie stosuje agresywnego filtra szybkości zmian, który mógłby ukryć prawdziwe zdarzenie.
- Odczyt wieloparametrowy jest już obsługiwany przez `Obd2Client.readBatch()` i włączany dopiero po udanej próbie potwierdzającej kompletność odpowiedzi. Nie jest to traktowane jako gwarancja wszystkich klonów ELM327.
- `ElmSession` odbiera dane aż do promptu `>` zamiast polegać na stałym opóźnieniu. Odpowiedzi wieloliniowe są składane przed parsowaniem.
- Mode 06 ma osobne limity czasu i jest realizowany przez jawne funkcje diagnostyczne, a nie dopisywany do zwykłego szybkiego harmonogramu PID-ów.
- Istniejący harmonogram już rozdziela szybkie, średnie i wolne PID-y oraz ogranicza liczbę PID-ów rozszerzonych na cykl; wolne parametry są rotowane, a odpowiedzi `NO DATA` czasowo odpoczywają.
- Konfiguracja protokołu może używać zapamiętanego protokołu, ale wraca do automatycznego wyboru po nieudanej próbie. Nie wymuszamy CAN 11/500 bez potwierdzenia, że dany adapter i auto odpowiadają.

### Granice i bezpieczeństwo diagnozy

- Zwykły SAE OBD-II PID `010D` nie gwarantuje surowej prędkości przed korektą licznika. Wersja 0.8.3 nie przedstawia go jako „rzeczywistej prędkości CAN” bez zweryfikowanego niestandardowego źródła.
- Moc i moment wyliczane z masy oraz pochodnej prędkości byłyby tylko szacunkiem obarczonym dużym błędem bez GPS o dobrej częstotliwości, nachylenia drogi, oporów i informacji o biegu. Nie są pokazywane jako pomiary ECU.
- Stan VTEC/VTC, liczniki misfire z modułów producenta, ELD/alternator, surowe prędkości z ABS/MICU i pozostałe dane producenta są oznaczane jako dostępne tylko wtedy, gdy konkretne PID-y/ramki są obsługiwane i zweryfikowane. Nie wysyłamy arbitralnych nagłówków do modułów krytycznych.
- Progi napięcia są wskazówkami, nie rozpoznaniem awarii alternatora: strategia ELD Hondy może celowo zmieniać napięcie ładowania. Napięcie `ATRV` nie jest gwarantowanym pomiarem bezpośrednio na zaciskach akumulatora.
- Powiadomienia Android Auto zależą od ograniczeń biblioteki Android for Cars i hosta. Nie gwarantujemy, że alarm OBD będzie mógł zasłonić nawigację; ważne alarmy powinny także korzystać z kanału powiadomień systemowych/głosu.

### Weryfikacja wydania 0.8.3

- Dodano testy jednostkowe deadband (drobne wahania, istotna zmiana, heartbeat).
- Nie oznaczamy builda jako zweryfikowanego, dopóki `./gradlew test` i `./gradlew :app:assembleDebug` nie zakończą się sukcesem w GitHub Actions. Test na fizycznym ESSGOO i konkretnym ELM327 pozostaje konieczny.
