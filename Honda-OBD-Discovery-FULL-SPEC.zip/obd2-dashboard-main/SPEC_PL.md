# Honda OBD Discovery — specyfikacja projektu

## Cel i zasada nadrzędna

Rozwijamy projekt źródłowy `obd2-dashboard-main`, zachowując jego dotychczasowe funkcje, elementy i logikę. Nie zastępujemy go nową aplikacją o podobnym wyglądzie. Zmiany UI mają być oddzielone od dekodowania danych, komunikacji OBD i logiki sesji.

## Środowisko docelowe

- Samochód: Honda Civic VIII UFO hatchback, 2010, 1.4 i-VTEC L13Z1, 100 KM, skrzynia manualna.
- Radio: ESSGOO, MT8163, ekran 1280×720.
- Android: rzeczywiste Android 9 / API 28.
- Architektura: ARMv7, 32-bit.
- Adapter: ELM327 BLE.
- Bez wymogu roota, Google Play Services i stałego dostępu do internetu.
- Cel 60 FPS jest celem optymalizacyjnym, nie gwarancją.

## Wygląd i obsługa

- Spójny styl inspirowany Apple CarPlay; automatyczny tryb dzień/noc.
- Czerń/grafit, biel, chłodna mięta i bursztynowe sygnały ostrzegawcze.
- Subtelne szkło, gradienty i głębia, ograniczane na słabszym sprzęcie.
- Zachować dotychczasowy układ i logikę dashboardu; nie usuwać działających elementów źródłowych.
- Priorytetowe wskaźniki: RPM, prędkość, temperatura płynu i napięcie, bez usuwania istniejących elementów.
- Stała nawigacja inspirowana CarPlay, przypinanie ekranów i szybki dostęp do DTC, wykresów oraz parametrów.
- Płynna wskazówka RPM, aktualizacja wartości bez migotania, przewijanie z bezwładnością, przesuwanie poziome między ekranami.
- Gesty: dwuklik kafelka rozwija szczegóły, długie przytrzymanie otwiera konfigurację; ważne akcje mają również widoczne przyciski.

## Parametry i wykresy

- Priorytet odpytywania: RPM, temperatura płynu, napięcie, prędkość, potem pozostałe obsługiwane parametry.
- Tempo odświeżania dopasować do ECU i adaptera; nie blokować UI i nie mieszać odpowiedzi komend.
- Wyraźnie odróżniać PID obsługiwany, chwilowo bez odpowiedzi, nieobsługiwany i eksperymentalny.
- Nie pokazywać nieaktualnych wartości jako świeżych.
- Miniwykresy przy wartościach, wykresy wielu parametrów, progi ostrzegawcze, powiększanie, przesuwanie i wybór zakresu czasu.
- Zachować istniejące funkcje wykresów i dashboardu źródłowego.

## BLE, ELM327 i autostart

- Zapamiętywanie adaptera BLE, lista nazw i adresów, skanowanie ręczne i automatyczne łączenie ze znanym urządzeniem.
- Próba połączenia po otwarciu aplikacji i po starcie Androida, jeśli system pozwala.
- Automatyczne ponawianie połączenia z ograniczaniem częstotliwości prób.
- Automatyczna inicjalizacja ELM327, weryfikacja rzeczywistych odpowiedzi i wykrywanie błędnych/niepełnych odpowiedzi.
- Tryb techniczny: usługi i charakterystyki GATT, komendy AT, odpowiedzi ELM327, błędy, przyczyny rozłączeń i eksport logów.
- W tle utrzymywać BLE i zapis, gdy system pozwala; informować o utracie/odzyskaniu połączenia.
- Po uśpieniu/wybudzeniu radia sprawdzić BLE, wznowić odczyty i jawnie oznaczyć przerwę w historii.
- Nie wykonywać równoległych komend mogących pomieszać odpowiedzi. Ograniczyć pętle reconnect.
- Jasno komunikować ograniczenia firmware'u, autostartu i pracy w tle.

## Diagnostyka OBD-II i Honda

- Zachować istniejące odczyty DTC, dashboard parametrów, profile pojazdu, sesje jazdy, historię, raporty i eksport.
- DTC: zapisane, oczekujące, trwałe; status aktualny/historyczny, polski opis, historia wystąpień i znikania.
- Wypadanie zapłonów: liczniki na cylinder, historia i alerty wyłącznie jeśli ECU rzeczywiście je udostępnia.
- STFT/LTFT, sondy lambda i porównania tylko dla dostępnych PID-ów.
- Freeze Frame, RPM, temperatura, obciążenie, napięcie i czas błędu, jeśli dane są dostępne.
- Monitory gotowości OBD-II: gotowe, niegotowe, nieobsługiwane; niegotowy monitor nie musi oznaczać usterki.
- Mode $06 tylko wtedy, gdy dane można poprawnie zinterpretować; nie zgadywać nieznanych wyników.
- Standardowe PID-y oraz dodatkowe PID-y Hondy tylko po wykryciu obsługi. Oddzielać dane potwierdzone od eksperymentalnych.
- Szczególna przydatność do analizy P0303, ale bez założenia, że dowolny adapter/ECU udostępnia wszystkie dane producenta.

## Kasowanie DTC — wymaganie krytyczne

Kasowanie błędów zarówno w głównej aplikacji, jak i w osobnym skrócie ma działać bez potwierdzenia użytkownika i bez dodatkowego ostrzeżenia przed operacją.

- Główna aplikacja: kliknięcie przycisku kasowania natychmiast uruchamia procedurę.
- Osobna pozycja systemowa/skró t: wyłącznie kasowanie DTC; ma być możliwa do wybrania/przypisania, o ile launcher i system to obsługują.
- Skrót zgłasza wynik powiadomieniem Androida.
- Nigdy nie zgłaszać sukcesu bez prawidłowej odpowiedzi potwierdzającej przyjęcie komendy przez ECU.
- Jeśli BLE/ECU jest niedostępne albo operacja nie została potwierdzona, zgłosić niepowodzenie.
- Należy zapewnić pojedynczego właściciela połączenia/serializację komend, aby dwa punkty wejścia nie mieszały odpowiedzi ELM327.
- Kasowanie może usunąć Freeze Frame i zresetować monitory gotowości; zgodnie z wymaganiem nie pokazywać przed nim potwierdzenia ani ostrzeżenia.

## Historia i ustawienia

- Lokalna historia bez obowiązkowej chmury; sesje z datą i czasem.
- Oznaczać przerwy i luki w danych.
- Eksport CSV, logów BLE, raportów diagnostycznych oraz konfiguracji; import konfiguracji.
- Możliwość usunięcia historii.
- Ustawienia dostępne z dashboardu: PID-y, częstotliwości odświeżania, adapter, motyw i jednostki.
- Polski interfejs; domyślnie °C i km/h, z możliwością zmiany jednostek.

## Dostarczenie i weryfikacja

- Dostarczyć kompletny ZIP projektu oraz workflow GitHub Actions.
- Testować kompilację, Android 9/API 28 i ARMv7, dekodowanie PID/DTC, błędne i niepełne odpowiedzi, BLE, reconnect, uśpienie/wybudzenie, autostart i kasowanie DTC.
- Potwierdzić, że skrót DTC nie zgłasza sukcesu bez potwierdzenia ECU.
- W raporcie odróżnić: zaprojektowane, skompilowane i przetestowane na urządzeniu.
- Ograniczenia ECU, ELM327 i firmware'u dokumentować wprost.

## Status

Ten dokument zapisuje wymagania użytkownika. Samo umieszczenie funkcji w specyfikacji nie oznacza, że została już zaimplementowana, skompilowana lub sprawdzona na radiu. Wymagane jest porównanie z kodem i testy.
