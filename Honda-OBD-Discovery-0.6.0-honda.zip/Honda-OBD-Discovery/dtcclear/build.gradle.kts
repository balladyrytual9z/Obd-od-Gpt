
plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.honda.obddtcclear"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.honda.obddtcclear"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        getByName("debug") {
            // Same checked-in development key as the main APK, required by the signature permission.
            storeFile = file("../app/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("debug") }
        getByName("release") { signingConfig = signingConfigs.getByName("debug") }
    }
}

