
package com.honda.obddtcclear;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Standalone launcher app: one action, routed to the main app's shared OBD engine. */
public final class ClearActivity extends Activity {
    private static final int BG = Color.rgb(8, 11, 9);
    private static final int MINT = Color.rgb(155, 231, 196);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        int pad = dp(26);
        root.setPadding(pad, pad, pad, pad);

        TextView brand = new TextView(this);
        brand.setText("HONDA  /  OBD DISCOVERY");
        brand.setTextColor(MINT); brand.setTextSize(13); brand.setLetterSpacing(.12f);
        root.addView(brand, params(-1, -2));

        TextView title = new TextView(this);
        title.setText("Kasuj DTC"); title.setTextColor(Color.WHITE); title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = params(-1, -2); titleLp.topMargin = dp(12);
        root.addView(title, titleLp);

        TextView status = new TextView(this);
        status.setText("Jedno kliknięcie. Wynik w powiadomieniu Androida.");
        status.setTextColor(Color.LTGRAY); status.setTextSize(14); status.setGravity(Gravity.CENTER);
        status.setPadding(dp(16), dp(20), dp(16), dp(20));
        status.setBackgroundColor(Color.rgb(23, 30, 25));
        LinearLayout.LayoutParams statusLp = params(-1, -2); statusLp.topMargin = dp(22);
        root.addView(status, statusLp);

        Button clear = new Button(this);
        clear.setText("KASUJ BŁĘDY DTC"); clear.setTextSize(16); clear.setAllCaps(false);
        clear.setTextColor(BG); clear.setBackgroundTintList(ColorStateList.valueOf(MINT));
        clear.setOnClickListener(v -> {
            Intent request = new Intent("com.miskibin.obd2dashboard.action.CLEAR_DTC");
            request.setPackage("com.miskibin.obd2dashboard");
            try {
                sendBroadcast(request);
                status.setText("Żądanie wysłane. Wynik pojawi się w powiadomieniu Androida.");
            } catch (RuntimeException e) {
                status.setText("Nie udało się przekazać żądania do Honda OBD Discovery.");
            }
        });
        LinearLayout.LayoutParams clearLp = params(-1, dp(64)); clearLp.topMargin = dp(18);
        root.addView(clear, clearLp);

        TextView note = new TextView(this);
        note.setText("Nie otwiera głównego dashboardu i nie tworzy drugiego połączenia BLE.");
        note.setTextColor(Color.GRAY); note.setTextSize(12); note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(16), 0, 0);
        root.addView(note, params(-1, -2));
        setContentView(root);
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
}

