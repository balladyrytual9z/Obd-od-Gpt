
# Honda OBD Discovery — specyfikacja projektu

## Cel
Rozbudować działający projekt `miskibin/obd2-dashboard`, zachowując jego logikę i działające połączenie OBD. Docelowy samochód: Honda Civic VIII UFO hatchback 2010, 1.4 i-VTEC L13Z1. Docelowe radio: ESSGOO, Android 9/API 28, ARMv7 32-bit, MT8163, ekran 1280×720, bez roota.

## UX i wygląd
- Jeden spójny styl inspirowany Apple CarPlay, grafit/czerń, miętowe akcenty i bursztynowe ostrzeżenia.
- Tryb dzień/noc zależny od ustawień systemu lub wybranego motywu.
- Stały lewy pasek na ekranach szerokich; dolna nawigacja na ekranach wąskich.
- Płynne, lekkie animacje i brak pełnego migotania UI podczas odświeżania danych.
- Zachować dotychczasowe funkcje źródłowego dashboardu: dashboard, PID-y, wykresy, DTC, Freeze Frame, Mode $06, profile, sesje jazdy, raporty i eksport.

## OBD / BLE
- Korzystać z jednego właściciela połączenia BLE/ELM327.
- Zachować skaner PID-ów, parser i scheduler źródłowego projektu.
- Automatyczne ponawianie połączenia ma korzystać z istniejącego mechanizmu `ConnectionManager`.
- Po utracie połączenia nie prezentować starych wartości jako świeżych; zapisywać luki w historii.
- Nie zgadywać nieobsługiwanych PID-ów ani danych Hondy.

## DTC
- Rozróżniać kody zapisane, oczekujące i trwałe, o ile ECU odpowiada na odpowiednie tryby.
- W głównej aplikacji kasowanie DTC bez potwierdzenia i bez ostrzeżenia.
- Dodatkowy, oddzielnie instalowany APK `Kasuj DTC` wykonuje tylko kasowanie i raportuje wynik powiadomieniem. Żądanie trafia przez podpisane uprawnienie do głównej aplikacji, która jest jedynym właścicielem połączenia BLE.
- Oba APK muszą być podpisane tym samym kluczem; workflow buduje je razem.
- Nie raportować sukcesu na podstawie samego wysłania komendy. Sprawdzać odpowiedź Mode 04 i ponownie odczytać DTC.

## Widget
- Rzeczywisty Android App Widget `Misfire Monitor`.
- Pokazuje stan połączenia, RPM, ECT, dostępny wynik misfire/Mode $06 i miniwykres RPM z rzeczywistych próbek.
- Korzysta ze wspólnego stanu połączenia, nie tworzy osobnego połączenia BLE.

## Autostart
- Po `BOOT_COMPLETED` wykonać cichą próbę połączenia z zapisanym adapterem i nie otwierać aktywności na pierwszym planie.
- Rzeczywiste zachowanie zależy od firmware'u i polityki uśpienia ESSGOO.

## Pakiet i weryfikacja
- Kotlin/Android, kompatybilność z API 28 i ARMv7.
- `./gradlew test` oraz `./gradlew :app:assembleDebug` w GitHub Actions.
- Kompilacja nie zastępuje testów na fizycznym radiu i konkretnym adapterze.

